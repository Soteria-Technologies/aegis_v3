// ============================================
// Library Availability Check
// ============================================

function checkLibrariesAvailable() {
    const libs = {
        leaflet: typeof L !== 'undefined',
        axios: typeof axios !== 'undefined',
        geotiff: typeof GeoTIFF !== 'undefined',
        parseGeoraster: typeof parseGeoraster !== 'function',
        georasterLayer: typeof GeoRasterLayer !== 'undefined' || 
                        (typeof L !== 'undefined' && L.GeoRasterLayer !== undefined),
        geoRasterLayerForLeaflet: typeof GeoRasterLayer !== 'undefined'
    };
    
    console.log('[INIT] Library Status:', libs);
    return libs;
}

// ============================================
// API Configuration - Auto-detect environment
const API_BASE_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'http://localhost:3001'
    : window.location.origin;

// Define world bounds to prevent map from looping
const worldBounds = L.latLngBounds(
    L.latLng(-85, -180),  // Southwest corner
    L.latLng(85, 180)     // Northeast corner
);

// Map initialization with bounds restriction
var map = L.map('map', {
    zoomControl: false,
    attributionControl: false,
    maxBounds: worldBounds,
    maxBoundsViscosity: 1.0,  // Solid boundary - prevents dragging outside
    minZoom: 2,               // Minimum zoom to show single planisphere
    maxZoom: 19,
    worldCopyJump: false      // Disable world copy jumping
}).setView([20, 0], 2);

// Fit to world bounds on initialization
map.setMaxBounds(worldBounds);

L.control.zoom({
    position: 'bottomright'
}).addTo(map);

var currentLayer = null;
var markersArray = [];
var isPlacingMarker = false;
var pendingMarkerData = null;
var currentZoom = 2;
var iconLibraryCache = {};
var userLocationMarker = null;
var isLoadingTiles = true;

const SIDEBAR_LIMITS = {
    left: { min: 240, max: 520, defaultValue: 320 },
    right: { min: 240, max: 420, defaultValue: 320 }
};

const sidebarResizeState = {
    activeTarget: null,
    startX: 0,
    startWidth: 0
};

let sidebarResizersInitialized = false;

// ============================================
// UI Theme System
// ============================================

/**
 * Built-in theme definitions
 */
const builtInThemes = {
    'default': {
        name: 'Tactical Dark',
        colors: {
            primary: '#1e293b',
            secondary: '#0f172a',
            accent: '#ffffff',
            accentHover: '#e2e8f0',
            border: '#475569',
            text: '#e2e8f0',
            textMuted: '#64748b',
            danger: '#d32f2f',
            success: '#22c55e',
            warning: '#fbbf24'
        },
        panelRgb: '30, 41, 59',
        font: "'Roboto Mono', monospace",
        class: ''
    },
    'light': {
        name: 'Light Mode',
        colors: {
            primary: '#ffffff',
            secondary: '#f1f5f9',
            accent: '#1e293b',
            accentHover: '#334155',
            border: '#cbd5e1',
            text: '#1e293b',
            textMuted: '#64748b',
            danger: '#dc2626',
            success: '#16a34a',
            warning: '#ca8a04'
        },
        panelRgb: '255, 245, 249',
        font: "'Roboto Mono', monospace",
        class: ''
    },
    'green': {
        name: 'Night Vision',
        colors: {
            primary: '#0a1f0a',
            secondary: '#051505',
            accent: '#00ff00',
            accentHover: '#33ff33',
            border: '#1a4a1a',
            text: '#00ff00',
            textMuted: '#009900',
            danger: '#ff3300',
            success: '#00ff66',
            warning: '#ffff00'
        },
        panelRgb: '5, 21, 5',
        font: "'Roboto Mono', monospace",
        class: ''
    },
    'blue': {
        name: 'Ocean Blue',
        colors: {
            primary: '#0c1929',
            secondary: '#061220',
            accent: '#3b82f6',
            accentHover: '#60a5fa',
            border: '#1e40af',
            text: '#bfdbfe',
            textMuted: '#60a5fa',
            danger: '#ef4444',
            success: '#10b981',
            warning: '#f59e0b'
        },
        panelRgb: '12, 25, 41',
        font: "'Roboto Mono', monospace",
        class: ''
    },
    'mi-fallout': {
        name: 'MI Fallout',
        colors: {
            primary: '#0d0d0d',
            secondary: '#1a1a1a',
            accent: '#e74c3c',
            accentHover: '#ff6b5a',
            border: '#2c3e50',
            text: '#ecf0f1',
            textMuted: '#95a5a6',
            danger: '#c0392b',
            success: '#27ae60',
            warning: '#e67e22'
        },
        panelRgb: '13, 13, 13',
        font: "'Roboto Mono', monospace",
        class: 'mi-fallout-theme'
    }
};

var currentTheme = 'default';

/**
 * Apply a theme to the UI
 */
function applyTheme(themeConfig) {
    const root = document.documentElement;
    const colors = themeConfig.colors;
    
    // Set CSS custom properties
    root.style.setProperty('--theme-primary', colors.primary);
    root.style.setProperty('--theme-secondary', colors.secondary);
    root.style.setProperty('--theme-accent', colors.accent);
    root.style.setProperty('--theme-accent-hover', colors.accentHover);
    root.style.setProperty('--theme-border', colors.border);
    root.style.setProperty('--theme-text', colors.text);
    root.style.setProperty('--theme-text-muted', colors.textMuted);
    root.style.setProperty('--theme-danger', colors.danger);
    root.style.setProperty('--theme-success', colors.success);
    root.style.setProperty('--theme-warning', colors.warning);
    root.style.setProperty('--theme-font', themeConfig.font);
    root.style.setProperty('--panel-rgb', themeConfig.panelRgb);
    
    // Apply to body
    document.body.style.fontFamily = themeConfig.font;
    
    // Remove all theme classes and apply the new one
    document.body.classList.remove('mi-fallout-theme', 'default-theme', 'light-theme', 'green-theme', 'blue-theme');
    if (themeConfig.class) {
        document.body.classList.add(themeConfig.class);
    }
    
    // Update grid color based on theme
    updateGridTheme(colors);
    
    // Update map background color based on theme
    updateMapBackground(themeConfig.name, colors);
    
    console.log('[THEME] Applied theme:', themeConfig.name);
}

/**
 * Update grid overlay color based on theme
 */
function updateGridTheme(colors) {
    const grid = document.getElementById('grid-overlay');
    if (!grid) return;
    
    // Determine if theme is light or dark based on primary color luminance
    const isLightTheme = isLightColor(colors.primary);
    
    if (isLightTheme) {
        // Light theme: use dark gray grid lines
        grid.style.backgroundImage = `
            linear-gradient(rgba(0, 0, 0, 0.08) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 0, 0, 0.08) 1px, transparent 1px)
        `;
    } else {
        // Dark theme: use light grid lines
        grid.style.backgroundImage = `
            linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px)
        `;
    }
}

/**
 * Check if a color is light (for determining contrast)
 */
function isLightColor(hexColor) {
    const hex = hexColor.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    // Calculate relative luminance
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5;
}

/**
 * Update map tiles background color based on theme
 */
function updateMapBackground(themeName, colors) {
    const mapContainer = document.querySelector('.leaflet-container');
    const mapWrapper = document.querySelector('.map-container');
    
    // Set background based on theme
    const isLight = isLightColor(colors.primary);
    let bgColor;
    
    if (isLight) {
        bgColor = '#f5f5f5';
    } else if (themeName === 'Night Vision') {
        bgColor = '#051505';
    } else {
        bgColor = colors.secondary;
    }
    
    if (mapContainer) {
        mapContainer.style.backgroundColor = bgColor;
    }
    if (mapWrapper) {
        mapWrapper.style.backgroundColor = bgColor;
    }
}

/**
 * Switch to a built-in theme
 */
function switchTheme(themeKey) {
    const theme = builtInThemes[themeKey];
    if (theme) {
        currentTheme = themeKey;
        applyTheme(theme);
        localStorage.setItem('aegisTheme', themeKey);
    }
}

/**
 * Load custom theme from JSON file
 */
function loadCustomTheme(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const themeData = JSON.parse(e.target.result);
            
            // Validate theme structure
            if (!themeData.colors || !themeData.name) {
                alert('Invalid theme file. Must contain "name" and "colors" properties.');
                return;
            }
            
            // Merge with default to fill missing values
            const fullTheme = {
                name: themeData.name,
                colors: { ...builtInThemes.default.colors, ...themeData.colors },
                panelRgb: themeData.panelRgb || builtInThemes.default.panelRgb,
                font: themeData.font || builtInThemes.default.font
            };
            
            applyTheme(fullTheme);
            
            // Add to selector
            const selector = document.getElementById('themeSelector');
            const customOption = document.createElement('option');
            customOption.value = 'custom';
            customOption.textContent = themeData.name + ' (Custom)';
            customOption.selected = true;
            selector.appendChild(customOption);
            
            console.log('[THEME] Loaded custom theme:', themeData.name);
        } catch (error) {
            console.error('Error loading theme:', error);
            alert('Error loading theme file: ' + error.message);
        }
    };
    reader.readAsText(file);
    
    // Reset file input
    event.target.value = '';
}

/**
 * Load saved theme on startup
 */
function loadSavedTheme() {
    const savedTheme = localStorage.getItem('aegisTheme');
    if (savedTheme && builtInThemes[savedTheme]) {
        currentTheme = savedTheme;
        applyTheme(builtInThemes[savedTheme]);
        
        const selector = document.getElementById('themeSelector');
        if (selector) selector.value = savedTheme;
    } else {
        applyTheme(builtInThemes.default);
    }
}

// Map layers definition
const mapLayers = {
    'osm-default': {
        name: 'OpenStreetMap Default',
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
    },
    'osm-light': {
        name: 'OpenStreetMap Light',
        url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
        attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/">CartoDB</a>'
    },
    'osm-dark': {
        name: 'OpenStreetMap Dark',
        url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/">CartoDB</a>'
    },
    'satellite': {
        name: 'Satellite',
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attribution: 'Tiles &copy; Esri'
    },
    'terrain': {
        name: 'Terrain',
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
        attribution: 'Tiles &copy; Esri'
    }
};

// ============================================
// Initialization
// ============================================

function showLoadingAnimation() {
    let loader = document.getElementById('tileLoader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'tileLoader';
        loader.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(58, 63, 71, 0.95);
            border: 2px solid #555;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            z-index: 10000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-width: 200px;
        `;
        
        const spinnerHTML = `
            <div style="display: flex; flex-direction: column; align-items: center; gap: 15px;">
                <div style="
                    width: 40px;
                    height: 40px;
                    border: 3px solid #555;
                    border-top: 3px solid #888;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                "></div>
                <p style="color: #d0d5dd; margin: 0; font-size: 14px; font-weight: 500;">Loading map tiles...</p>
            </div>
        `;
        
        loader.innerHTML = spinnerHTML;
        document.body.appendChild(loader);
        
        // Add CSS animation
        if (!document.getElementById('spinnerStyle')) {
            const style = document.createElement('style');
            style.id = 'spinnerStyle';
            style.textContent = `
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
    }
    loader.style.display = 'flex';
    
    // Auto-hide after 10 seconds if tiles haven't loaded
    setTimeout(() => {
        if (loader) {
            loader.style.display = 'none';
            isLoadingTiles = false;
        }
    }, 10000);
}

function hideLoadingAnimation() {
    const loader = document.getElementById('tileLoader');
    if (loader) {
        loader.style.display = 'none';
    }
}

// ============================================
// Initialization
// ============================================

function initializeMap() {
    // First, check library availability
    const libs = checkLibrariesAvailable();
    console.log('[INIT] Initializing map with libraries:', libs);
    
    // Add library status to console for debugging
    if (!libs.georasterLayer) {
        console.warn('[INIT] WARNING: GeoRasterLayer not yet available. Will try again in 500ms.');
        // Retry after a short delay
        setTimeout(() => {
            const retryLibs = checkLibrariesAvailable();
            console.log('[INIT] Library retry check:', retryLibs);
            if (retryLibs.georasterLayer) {
                console.log('[INIT] GeoRasterLayer is now available!');
            }
        }, 500);
    }
    
    loadSavedTheme();
    switchMapLayer('osm-default');
    loadMarkersFromStorage();
    loadIconLibrary();
    setupEventListeners();
    setupMapZoomListener();
    updateTifLayersList();
    initSidebarResizers();
}

// ============================================
// Sidebar Resize Controls
// ============================================

function initSidebarResizers() {
    if (sidebarResizersInitialized) return;
    sidebarResizersInitialized = true;
    const handles = document.querySelectorAll('.sidebar-resize-handle');
    handles.forEach(handle => handle.addEventListener('mousedown', startSidebarResize));
    window.addEventListener('mousemove', handleSidebarResizeDrag);
    window.addEventListener('mouseup', stopSidebarResize);
    window.addEventListener('mouseleave', stopSidebarResize);
}

function startSidebarResize(event) {
    const target = event.currentTarget.dataset.target;
    if (!target) return;
    sidebarResizeState.activeTarget = target;
    sidebarResizeState.startX = event.clientX;
    sidebarResizeState.startWidth = getSidebarWidth(target);
    document.body.classList.add('resizing-sidebar');
    event.preventDefault();
}

function handleSidebarResizeDrag(event) {
    if (!sidebarResizeState.activeTarget) return;
    const deltaX = event.clientX - sidebarResizeState.startX;
    let newWidth = sidebarResizeState.startWidth;
    if (sidebarResizeState.activeTarget === 'left') {
        newWidth += deltaX;
    } else {
        newWidth -= deltaX;
    }
    setSidebarWidth(sidebarResizeState.activeTarget, newWidth);
}

function stopSidebarResize() {
    if (!sidebarResizeState.activeTarget) return;
    sidebarResizeState.activeTarget = null;
    document.body.classList.remove('resizing-sidebar');
}

function getSidebarWidth(target) {
    const cssVar = target === 'left' ? '--left-sidebar-width' : '--right-panel-width';
    const currentValue = getComputedStyle(document.documentElement).getPropertyValue(cssVar).trim();
    const parsed = parseFloat(currentValue);
    if (Number.isFinite(parsed)) {
        return parsed;
    }
    return SIDEBAR_LIMITS[target]?.defaultValue || 320;
}

function setSidebarWidth(target, width) {
    const cssVar = target === 'left' ? '--left-sidebar-width' : '--right-panel-width';
    const limits = SIDEBAR_LIMITS[target];
    if (!limits) return;
    const clamped = Math.max(limits.min, Math.min(limits.max, width));
    document.documentElement.style.setProperty(cssVar, `${Math.round(clamped)}px`);
}

// ============================================
// Icon Library Management
// ============================================

function loadIconLibrary() {
    // Load PNG files from ./icons/ folder
    fetch('./icons/')
        .then(response => response.text())
        .then(html => {
            // Parse directory listing - supports both Apache and common web servers
            const pngRegex = /href=["']?([^"'\s<>]*\.png)["']?/gi;
            let match;
            const foundIcons = [];
            
            while ((match = pngRegex.exec(html)) !== null) {
                let filename = match[1];
                // Clean up the filename (remove directory prefix if present)
                filename = filename.split('/').pop();
                
                if (filename && filename.endsWith('.png')) {
                    const iconKey = filename.replace('.png', '');
                    iconLibraryCache[iconKey] = {
                        path: './icons/' + filename,
                        name: iconKey
                    };
                    foundIcons.push(iconKey);
                }
            }
            
            // Update select dropdown
            if (foundIcons.length > 0) {
                updateIconSelector(foundIcons);
                console.log('Loaded icons:', foundIcons);
            } else {
                console.log('No icons found in /icons/ folder');
            }
        })
        .catch(error => {
            console.log('Icon library load error:', error);
            // Try alternative approach - fetch directory as JSON if available
            loadIconsAlternative();
        });
}

function loadIconsAlternative() {
    // Fallback: hardcode known icons from /icons/ folder
    const knownIcons = ['Aircraft', 'Analog Interface', 'Contingency', 'Godmode', 'Irrelevant threat', 'Relevant Vehicle', 'Relevant-One'];
    
    knownIcons.forEach(iconName => {
        iconLibraryCache[iconName] = {
            path: './icons/' + iconName + '.png',
            name: iconName
        };
    });
    
    updateIconSelector(knownIcons);
    console.log('Loaded icons from fallback list');
}

function updateIconSelector(iconList) {
    const selector = document.getElementById('iconSelector');
    const currentOptions = Array.from(selector.options).map(o => o.value);
    
    iconList.forEach(icon => {
        if (!currentOptions.includes(icon)) {
            const option = document.createElement('option');
            option.value = icon;
            option.textContent = icon;  // Use the icon name as-is
            selector.appendChild(option);
        }
    });
}

// ============================================
// Marker Size Calculation (Zoom-Aware)
// ============================================

function getMarkerSize() {
    // Scale markers based on zoom level
    const baseSize = 32;
    const minSize = 20;
    const maxSize = 48;
    
    // Calculate size: smaller when zoomed out, larger when zoomed in
    const scaleFactor = Math.max(0.5, Math.min(1.5, currentZoom / 13));
    const size = Math.round(baseSize * scaleFactor);
    
    return Math.max(minSize, Math.min(maxSize, size));
}

// ============================================
// Map Layer Management
// ============================================

function switchMapLayer(layerKey) {
    if (currentLayer) {
        map.removeLayer(currentLayer);
    }
    
    isLoadingTiles = true;
    showLoadingAnimation();
    
    const layer = mapLayers[layerKey];
    currentLayer = L.tileLayer(layer.url, {
        attribution: layer.attribution,
        maxZoom: 19
    }).addTo(map);
    
    // Listen for tiles to load
    currentLayer.on('load', () => {
        isLoadingTiles = false;
        hideLoadingAnimation();
    });
}

// ============================================
// Marker Creation & Management
// ============================================

function createCustomIcon(iconType) {
    const markerSize = getMarkerSize();
    
    // Check if it's a PNG from library
    if (iconLibraryCache[iconType]) {
        return L.icon({
            iconUrl: iconLibraryCache[iconType].path,
            iconSize: [markerSize, markerSize],
            iconAnchor: [markerSize / 2, markerSize],
            popupAnchor: [0, -markerSize]
        });
    }
    
    // Fallback: colored circle markers
    const colors = {
        'marker-red': '#e74c3c',
        'marker-blue': '#3498db',
        'marker-green': '#2ecc71',
        'marker-yellow': '#f39c12',
        'marker-purple': '#9b59b6',
        'default': '#555'
    };
    
    const color = colors[iconType] || colors['default'];
    
    return L.divIcon({
        className: 'custom-marker',
        html: `<div style="background-color: ${color}; width: ${markerSize}px; height: ${markerSize}px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
        iconSize: [markerSize, markerSize],
        iconAnchor: [markerSize / 2, markerSize],
        popupAnchor: [0, -markerSize]
    });
}

function addMarker(lat, lng, name, description, iconType = 'default') {
    const markerData = {
        id: Date.now(),
        name: name || 'Unnamed Marker',
        description: description || '',
        location: [lat, lng],
        icon: iconType
    };
    
    const coordsText = lat.toFixed(5) + ' / ' + lng.toFixed(5);
    
    // Create popup 
    const popupContent = `
        <div class="marker-popup" data-marker-id="${markerData.id}">
            <div class="popup-resize-handle"></div>
            <div class="popup-title">${markerData.name}</div>
            <div class="popup-description">${markerData.description.replace(/\n/g, '<br>')}</div>
            <div class="popup-coordinates" style="font-size: 11px; color: #999; margin: 8px 0; padding: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; cursor: pointer;" title="Click to copy coordinates" data-coords="${coordsText}">
                [LOC] ${coordsText}
            </div>
            <button class="popup-btn" onclick="editMarker(${markerData.id})">Edit</button>
            <button class="popup-btn" onclick="deleteMarker(${markerData.id})">Delete</button>
        </div>
    `;
    
    const marker = L.marker([lat, lng], {
        icon: createCustomIcon(iconType)
    }).addTo(map);
    
    marker.bindPopup(popupContent);
    marker.markerData = markerData;
    
    // Setup popup resize functionality
    marker.on('popupopen', () => {
        setTimeout(() => {
            enablePopupResize();
            // Add click handler for coordinates in popup
            const coordsDiv = document.querySelector('.popup-coordinates');
            if (coordsDiv) {
                coordsDiv.addEventListener('click', (e) => {
                    e.stopPropagation();
                    copyToClipboard(coordsDiv.dataset.coords, 'Coordinates copied!');
                });
            }
        }, 100);
    });
    
    // Click on marker to pan to it
    marker.on('click', () => {
        map.setView([lat, lng], map.getZoom());
    });
    
    markersArray.push({ marker: marker, data: markerData });
    updateMarkerList();
    
    return markerData;
}

function deleteMarker(markerId) {
    markersArray = markersArray.filter(m => {
        if (m.data.id === markerId) {
            map.removeLayer(m.marker);
            return false;
        }
        return true;
    });
    updateMarkerList();
    autoSaveMarkers();
}

function editMarker(markerId) {
    const markerObj = markersArray.find(m => m.data.id === markerId);
    if (markerObj) {
        const newName = prompt('Enter new name:', markerObj.data.name);
        if (newName !== null) {
            const newDesc = prompt('Enter new description:', markerObj.data.description);
            
            markerObj.data.name = newName;
            markerObj.data.description = newDesc || '';
            
            const popupContent = `
                <div class="marker-popup" data-marker-id="${markerObj.data.id}">
                    <div class="popup-resize-handle"></div>
                    <div class="popup-title">${markerObj.data.name}</div>
                    <div class="popup-description">${markerObj.data.description.replace(/\n/g, '<br>')}</div>
                    <button class="popup-btn" onclick="editMarker(${markerObj.data.id})">Edit</button>
                    <button class="popup-btn" onclick="deleteMarker(${markerObj.data.id})">Delete</button>
                </div>
            `;
            
            markerObj.marker.setPopupContent(popupContent);
            markerObj.marker.openPopup();
            
            // Setup resize for updated popup
            setTimeout(() => enablePopupResize(), 100);
            
            updateMarkerList();
            autoSaveMarkers();
        }
    }
}

// ============================================
// Search & Place Features
// ============================================

function searchPlace() {
    const searchQuery = document.getElementById('searchInput').value.trim();
    if (!searchQuery) {
        alert('Please enter a place name');
        return;
    }
    
    // Use OpenStreetMap Nominatim API for geocoding
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`)
        .then(response => response.json())
        .then(results => {
            if (results.length === 0) {
                alert('Place not found. Try a different search term.');
                return;
            }
            
            // Use the first result
            const result = results[0];
            const lat = parseFloat(result.lat);
            const lng = parseFloat(result.lon);
            
            map.setView([lat, lng], 12);
            
            // Add a temporary marker for the search result
            const tempMarker = L.marker([lat, lng], {
                icon: L.divIcon({
                    className: 'search-result-marker',
                    html: '<div style="background-color: #e74c3c; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white;"></div>',
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                })
            }).addTo(map).bindPopup(`<b>${result.name}</b>`).openPopup();
            
            // Remove the temporary marker after 5 seconds
            setTimeout(() => {
                map.removeLayer(tempMarker);
            }, 5000);
        })
        .catch(error => {
            console.error('Search error:', error);
            alert('Error searching for place. Please try again.');
        });
}

// ============================================
// Shape Drawing Features
// ============================================

var isDrawingShape = false;
var currentShapeType = null;
var shapePoints = [];
var tempPolyline = null;
var shapesArray = [];
var selectedShape = null;

// ============================================
// TIF Overlay Management
// ============================================

var tifLayers = [];
var tifLayerId = 0;

/**
 * Color ramps for TIF visualization
 */
const colorRamps = {
    'grayscale': (value) => [value, value, value],
    'viridis': (value) => {
        const t = value / 255;
        const r = Math.round(68 + (253 - 68) * t);
        const g = Math.round(1 + (231 - 1) * Math.sin(Math.PI * t));
        const b = Math.round(84 + (37 - 84) * t);
        return [r, g, b];
    },
    'plasma': (value) => {
        const t = value / 255;
        const r = Math.round(13 + (240 - 13) * t);
        const g = Math.round(8 + (249 - 8) * Math.pow(t, 0.5));
        const b = Math.round(135 + (33 - 135) * t);
        return [r, g, b];
    },
    'inferno': (value) => {
        const t = value / 255;
        const r = Math.round(0 + 252 * Math.min(1, t * 1.5));
        const g = Math.round(0 + 255 * Math.pow(t, 2));
        const b = Math.round(4 + (164 - 4) * (1 - Math.abs(t - 0.5) * 2));
        return [r, g, b];
    },
    'terrain': (value) => {
        const t = value / 255;
        if (t < 0.25) return [0, Math.round(100 + 155 * (t / 0.25)), 0]; // Green
        if (t < 0.5) return [Math.round(255 * ((t - 0.25) / 0.25)), 255, 0]; // Yellow-Green
        if (t < 0.75) return [255, Math.round(255 - 155 * ((t - 0.5) / 0.25)), 0]; // Orange
        return [Math.round(200 + 55 * ((t - 0.75) / 0.25)), Math.round(100 * (1 - (t - 0.75) / 0.25)), Math.round(100 * (1 - (t - 0.75) / 0.25))]; // Red-Brown
    },
    'red': (value) => [value, 0, 0],
    'green': (value) => [0, value, 0],
    'blue': (value) => [0, 0, value],
    'heat': (value) => {
        const t = value / 255;
        return [Math.round(255 * Math.min(1, t * 2)), Math.round(255 * Math.max(0, t - 0.5) * 2), 0];
    }
};

function buildColorFunction(min, max, noDataValue, colorRampName) {
    const safeMin = Number.isFinite(min) ? min : 0;
    const safeMax = Number.isFinite(max) ? max : 255;
    const range = safeMax - safeMin || 1;
    const ramp = colorRamps[colorRampName] || colorRamps.grayscale;
    
    return function(values) {
        const val = Array.isArray(values) ? values[0] : values;
        
        // Handle no-data values
        if (val === null || val === undefined || !isFinite(val) || val === noDataValue) {
            return 'rgba(0, 0, 0, 0)'; // Transparent
        }
        
        const normalized = Math.max(0, Math.min(255, Math.round(((val - safeMin) / range) * 255)));
        const [r, g, b] = ramp(normalized);
        return `rgba(${r},${g},${b},1)`;
    };
}

/**
 * Handle TIF file upload
 */
function handleTifUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    console.log('[TIF] File selected:', file.name, '(' + file.size + ' bytes)');
    
    // Quick library check before processing
    if (typeof parseGeoraster === 'undefined') {
        alert('[TIF] Error: parseGeoraster not loaded. Please wait for page to fully load and refresh if needed.');
        console.error('[TIF] parseGeoraster is undefined');
        return;
    }
    
    if (typeof GeoRasterLayer === 'undefined' && 
        (typeof L === 'undefined' || L.GeoRasterLayer === undefined)) {
        alert('[TIF] Error: GeoRasterLayer not loaded. Please refresh the page and wait for all libraries to initialize.');
        console.error('[TIF] GeoRasterLayer is undefined. Available on L:', typeof L !== 'undefined' ? Object.keys(L).filter(k => k.includes('Geo')) : 'L not available');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = async function(e) {
        try {
            console.log('[TIF] File loaded, processing...');
            await loadTifFile(e.target.result, file.name);
            console.log('[TIF] File uploaded:', file.name);
        } catch (error) {
            console.error('[TIF] Upload failed:', error);
            alert('Error loading TIF file: ' + error.message);
        }
    };
    reader.onerror = function(error) {
        console.error('[TIF] File read error:', error);
        alert('[TIF] File read error: ' + error);
    };
    reader.readAsArrayBuffer(file);
    
    // Reset file input
    event.target.value = '';
}

/**
 * Load and display TIF/GeoTIFF file on map using GeoRasterLayer
 * Main function that handles the loading process
 */
async function loadTifFile(arrayBuffer, filename) {
    try {
        // Check if parseGeoraster is available
        if (typeof parseGeoraster === 'undefined') {
            throw new Error('[TIF] parseGeoraster not loaded. Please wait for libraries to load or refresh the page.');
        }
        
        // Check for GeoRasterLayer - try multiple possible names
        let GeoRasterLayerClass = null;
        if (typeof GeoRasterLayer !== 'undefined') {
            GeoRasterLayerClass = GeoRasterLayer;
        } else if (window.GeoRasterLayer !== undefined) {
            GeoRasterLayerClass = window.GeoRasterLayer;
        } else if (typeof L !== 'undefined' && L.GeoRasterLayer !== undefined) {
            GeoRasterLayerClass = L.GeoRasterLayer;
        }
        
        if (!GeoRasterLayerClass) {
            throw new Error('[TIF] GeoRasterLayer not loaded. The georaster-layer-for-leaflet library may not have initialized. Please refresh the page.');
        }
        
        console.log('[TIF] Loading:', filename);
        
        // Parse the GeoTIFF file
        const georaster = await parseGeoraster(arrayBuffer);
        
        console.log('[TIF] Parsed georaster:', {
            width: georaster.width,
            height: georaster.height,
            noDataValue: georaster.noDataValue,
            pixelWidth: georaster.pixelWidth,
            pixelHeight: georaster.pixelHeight
        });
        
        // Extract metadata
        const width = georaster.width || 0;
        const height = georaster.height || 0;
        const noDataValue = georaster.noDataValue ?? null;
        
        // Get min/max values from georaster
        let min = 0, max = 255;
        if (georaster.mins && Array.isArray(georaster.mins)) {
            min = georaster.mins[0] ?? 0;
        } else if (typeof georaster.mins === 'number') {
            min = georaster.mins;
        }
        
        if (georaster.maxs && Array.isArray(georaster.maxs)) {
            max = georaster.maxs[0] ?? 255;
        } else if (typeof georaster.maxs === 'number') {
            max = georaster.maxs;
        }
        
        const tifId = tifLayerId++;
        const colorRampName = 'grayscale';
        
        console.log(`[TIF] Raster dimensions: ${width}x${height} | Range: ${min} to ${max}`);
        
        // Build color function
        const colorFunction = buildColorFunction(min, max, noDataValue, colorRampName);
        
        // Create GeoRasterLayer with resolved class
        const georasterLayer = new GeoRasterLayerClass({
            georaster: georaster,
            opacity: 1,
            resolution: 256,
            pixelValuesToColorFn: colorFunction,
            debugLevel: 0
        });
        
        // Add to map
        georasterLayer.addTo(map);
        
        // Get bounds from georaster
        let bounds = null;
        if (georaster.xmin !== undefined && georaster.xmax !== undefined && 
            georaster.ymin !== undefined && georaster.ymax !== undefined) {
            bounds = L.latLngBounds([
                [georaster.ymin, georaster.xmin],
                [georaster.ymax, georaster.xmax]
            ]);
        }
        
        // Create layer record
        const tifLayer = {
            id: tifId,
            name: filename,
            overlay: georasterLayer,
            opacity: 1,
            bounds: bounds,
            colorRamp: colorRampName,
            min: min,
            max: max,
            noDataValue: noDataValue,
            width: width,
            height: height,
            georaster: georaster
        };
        
        tifLayers.push(tifLayer);
        
        // Update UI
        updateTifZIndices();
        updateTifLayersList();
        
        // Auto-zoom to layer if bounds are available
        if (bounds) {
            const currentBounds = map.getBounds();
            if (!currentBounds.intersects(bounds)) {
                map.fitBounds(bounds, {
                    padding: [50, 50],
                    maxZoom: 16
                });
            }
        }
        
        console.log('[TIF] Layer successfully loaded:', filename);
        
    } catch (error) {
        console.error('[TIF] Load error:', error);
        throw error;
    }
}

/**
 * Update TIF layers list in UI
 */
function updateTifLayersList() {
    const listContainer = document.getElementById('tifLayersList');
    if (!listContainer) return;
    
    listContainer.innerHTML = '';
    
    if (tifLayers.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--theme-text-muted, #64748b); text-align: center; font-size: 11px; padding: 12px;">No TIF layers loaded</p>';
        return;
    }
    
    // Display layers in reverse order (top layer first)
    [...tifLayers].reverse().forEach((tifLayer, displayIndex) => {
        const realIndex = tifLayers.length - 1 - displayIndex;
        const item = document.createElement('div');
        item.className = 'tif-layer-item';
        
        // Create color ramp options
        const colorRampOptions = Object.keys(colorRamps).map(ramp => 
            `<option value="${ramp}" ${tifLayer.colorRamp === ramp ? 'selected' : ''}>${ramp}</option>`
        ).join('');
        
        item.innerHTML = `
            <div class="tif-layer-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <div class="tif-layer-name" style="font-weight: 600; color: white; flex: 1; word-break: break-all; font-size: 12px;">${tifLayer.name}</div>
                <input type="checkbox" ${tifLayer.overlay._map ? 'checked' : ''} onchange="toggleTifLayerVisibility(${tifLayer.id})" title="Toggle visibility" style="margin: 0 8px; cursor: pointer; width: 16px; height: 16px;">
            </div>
            
            <div class="tif-layer-controls">
                <div class="opacity-control">
                    <label>Opacity:</label>
                    <input type="range" min="0" max="100" value="${Math.round(tifLayer.opacity * 100)}" 
                           oninput="setTifOpacity(${tifLayer.id}, this.value / 100)" class="opacity-slider" style="flex: 1;">
                    <span class="opacity-value">${Math.round(tifLayer.opacity * 100)}%</span>
                </div>
                
                <div class="color-control" style="display: flex; align-items: center; gap: 8px; font-size: 11px; margin-top: 6px;">
                    <label style="min-width: 60px;">Color Ramp:</label>
                    <select onchange="setTifColorRamp(${tifLayer.id}, this.value)" class="color-select" style="flex: 1;">
                        ${colorRampOptions}
                    </select>
                </div>
                
                <div class="tif-layer-buttons" style="display: flex; gap: 6px; margin-top: 8px;">
                    <button class="tif-layer-btn" onclick="zoomToTifLayer(${tifLayer.id})" title="Zoom to this layer" style="flex: 1; padding: 6px; font-size: 11px; border: 1px solid #475569; background-color: rgba(0, 0, 0, 0.2); color: #cbd5e1; border-radius: 3px; cursor: pointer;">Zoom</button>
                    ${realIndex > 0 ? `<button class="tif-layer-btn move-up" onclick="moveTifLayer(${tifLayer.id}, 'up')" title="Move layer up" style="flex: 0.5; padding: 6px; font-size: 11px; border: 1px solid #475569; background-color: rgba(0, 0, 0, 0.2); color: #cbd5e1; border-radius: 3px; cursor: pointer;">[UP]</button>` : ''}
                    ${realIndex < tifLayers.length - 1 ? `<button class="tif-layer-btn move-down" onclick="moveTifLayer(${tifLayer.id}, 'down')" title="Move layer down" style="flex: 0.5; padding: 6px; font-size: 11px; border: 1px solid #475569; background-color: rgba(0, 0, 0, 0.2); color: #cbd5e1; border-radius: 3px; cursor: pointer;">[DN]</button>` : ''}
                    <button class="tif-layer-btn remove" onclick="removeTifLayer(${tifLayer.id})" title="Remove this layer" style="flex: 0.5; padding: 6px; font-size: 11px; border: 1px solid #7f1d1d; background-color: rgba(0, 0, 0, 0.2); color: #f87171; border-radius: 3px; cursor: pointer;">[X]</button>
                </div>
                
                <div class="tif-info-text" style="font-size: 10px; color: #64748b; margin-top: 6px; padding-top: 6px; border-top: 1px solid rgba(255, 255, 255, 0.1);">
                    ${tifLayer.width}×${tifLayer.height} | Range: ${Math.round(tifLayer.min)} - ${Math.round(tifLayer.max)}
                </div>
            </div>
        `;
        
        listContainer.appendChild(item);
    });
}

/**
 * Set color ramp of TIF layer
 */
function setTifColorRamp(tifId, colorRampName) {
    const tifLayer = tifLayers.find(t => t.id === tifId);
    if (!tifLayer || !tifLayer.overlay) return;
    
    tifLayer.colorRamp = colorRampName;
    
    // Update the color function for GeoRasterLayer
    tifLayer.overlay.options.pixelValuesToColorFn = buildColorFunction(
        tifLayer.min,
        tifLayer.max,
        tifLayer.noDataValue,
        colorRampName
    );
    
    // Trigger redraw if available
    if (typeof tifLayer.overlay.redraw === 'function') {
        tifLayer.overlay.redraw();
    }
    
    console.log(`[TIF] Color ramp changed to: ${colorRampName}`);
    updateTifLayersList();
}

/**
 * Toggle visibility of TIF layer
 */
function toggleTifLayerVisibility(tifId) {
    const tifLayer = tifLayers.find(t => t.id === tifId);
    if (!tifLayer) return;
    
    if (tifLayer.overlay._map) {
        // Layer is visible, hide it
        map.removeLayer(tifLayer.overlay);
        console.log(`[TIF] Layer ${tifId} hidden`);
    } else {
        // Layer is hidden, show it
        tifLayer.overlay.addTo(map);
        tifLayer.overlay.setOpacity(tifLayer.opacity);
        console.log(`[TIF] Layer ${tifId} shown`);
    }
    
    updateTifZIndices();
    updateTifLayersList();
}

/**
 * Zoom to TIF layer bounds - Pan to show TIF without changing zoom
 */
function zoomToTifLayer(tifId) {
    const tifLayer = tifLayers.find(t => t.id === tifId);
    if (!tifLayer) return;
    const bounds = tifLayer.bounds || (tifLayer.overlay?.getBounds ? tifLayer.overlay.getBounds() : null);
    if (bounds) {
        // Fit bounds but maintain current zoom level
        map.fitBounds(bounds, { 
            padding: [50, 50],
            maxZoom: map.getZoom() // Preserve current zoom
        });
    }
}

/**
 * Set opacity of TIF layer
 */
function setTifOpacity(tifId, opacity) {
    const tifLayer = tifLayers.find(t => t.id === tifId);
    if (!tifLayer) return;
    
    // Clamp opacity to 0-1 range
    tifLayer.opacity = Math.max(0, Math.min(1, opacity));
    
    if (tifLayer.overlay && typeof tifLayer.overlay.setOpacity === 'function') {
        tifLayer.overlay.setOpacity(tifLayer.opacity);
    }
    
    updateTifLayersList();
}

/**
 * Move TIF layer up or down in z-order
 */
function moveTifLayer(tifId, direction) {
    const index = tifLayers.findIndex(t => t.id === tifId);
    if (index === -1) return;
    
    if (direction === 'up' && index < tifLayers.length - 1) {
        [tifLayers[index], tifLayers[index + 1]] = [tifLayers[index + 1], tifLayers[index]];
        updateTifZIndices();
    } else if (direction === 'down' && index > 0) {
        [tifLayers[index], tifLayers[index - 1]] = [tifLayers[index - 1], tifLayers[index]];
        updateTifZIndices();
    }
    
    updateTifLayersList();
}

/**
 * Update z-indices for all TIF layers
 */
function updateTifZIndices() {
    tifLayers.forEach((tifLayer, index) => {
        const newZIndex = 100 + index;
        if (tifLayer.overlay && typeof tifLayer.overlay.setZIndex === 'function') {
            tifLayer.overlay.setZIndex(newZIndex);
            tifLayer.overlay.options.zIndex = newZIndex;
        }
    });
}

/**
 * Remove TIF layer
 */
function removeTifLayer(tifId) {
    const index = tifLayers.findIndex(t => t.id === tifId);
    if (index === -1) return;
    
    const tifLayer = tifLayers[index];
    
    // Remove from map if visible
    if (tifLayer.overlay && tifLayer.overlay._map) {
        map.removeLayer(tifLayer.overlay);
    }
    
    // Remove from array
    tifLayers.splice(index, 1);
    
    console.log(`[TIF] Removed layer: ${tifLayer.name}`);
    updateTifLayersList();
    updateTifZIndices();
}

/**
 * Remove all TIF layers
 */
function removeAllTifLayers() {
    if (!confirm('Remove all TIF layers?')) return;
    
    tifLayers.forEach(tifLayer => {
        if (tifLayer.overlay && tifLayer.overlay._map) {
            map.removeLayer(tifLayer.overlay);
        }
    });
    tifLayers = [];
    console.log('[TIF] All layers removed');
    updateTifLayersList();
    updateTifZIndices();
}

function startDrawingShape(shapeType) {
    if (isDrawingShape) {
        alert('Already drawing a shape. Finish or cancel first.');
        return;
    }
    
    isDrawingShape = true;
    currentShapeType = shapeType;
    shapePoints = [];
    
    const drawBtn = document.getElementById(`draw${shapeType.charAt(0).toUpperCase() + shapeType.slice(1)}Btn`);
    drawBtn.textContent = `Drawing ${shapeType}... (Right-click to finish)`;
    drawBtn.style.backgroundColor = '#e74c3c';
    drawBtn.style.color = 'white';
    
    map._container.style.cursor = 'crosshair';
}

function finishDrawingShape() {
    if (!isDrawingShape) {
        alert('No shape being drawn');
        return;
    }
    
    const minPoints = currentShapeType === 'circle' ? 1 : 2;
    if (shapePoints.length < minPoints) {
        alert(`Need at least ${minPoints} point(s) to create a ${currentShapeType}`);
        return;
    }
    
    const color = '#3498db';
    const weight = 2;
    const shapeId = Date.now();
    let shapeLayer = null;
    
    if (currentShapeType === 'circle' && shapePoints.length >= 1) {
        // For single point, use default radius of 1000 meters
        let radius = 1000;
        if (shapePoints.length === 2) {
            // If user provided 2 points, calculate radius from them
            radius = map.latLngToLayerPoint(shapePoints[0]).distanceTo(
                map.latLngToLayerPoint(shapePoints[1])
            );
        }
        shapeLayer = L.circle(shapePoints[0], radius, {
            color: color,
            weight: weight,
            fillColor: color,
            fillOpacity: 0.2
        }).addTo(map);
        
        shapeLayer.shapeData = {
            id: shapeId,
            type: 'circle',
            center: shapePoints[0],
            radius: radius,
            color: color,
            weight: weight
        };
    } else if (currentShapeType === 'rectangle' && shapePoints.length === 2) {
        shapeLayer = L.rectangle([
            [shapePoints[0].lat, shapePoints[0].lng],
            [shapePoints[1].lat, shapePoints[1].lng]
        ], {
            color: color,
            weight: weight,
            fillColor: color,
            fillOpacity: 0.2
        }).addTo(map);
        
        shapeLayer.shapeData = {
            id: shapeId,
            type: 'rectangle',
            bounds: [
                [shapePoints[0].lat, shapePoints[0].lng],
                [shapePoints[1].lat, shapePoints[1].lng]
            ],
            color: color,
            weight: weight
        };
    } else if (currentShapeType === 'polygon' && shapePoints.length >= 3) {
        shapeLayer = L.polygon(shapePoints, {
            color: color,
            weight: weight,
            fillColor: color,
            fillOpacity: 0.2
        }).addTo(map);
        
        shapeLayer.shapeData = {
            id: shapeId,
            type: 'polygon',
            points: shapePoints,
            color: color,
            weight: weight
        };
    }
    
    if (shapeLayer) {
        // Add click handler to edit/delete shape
        shapeLayer.on('click', () => {
            showShapeContextMenu(shapeLayer);
        });
        
        shapesArray.push(shapeLayer);
        autoSaveMarkers();  // Save shapes along with markers
    }
    
    cancelDrawingShape();
}

function showShapeContextMenu(shapeLayer) {
    const shapeData = shapeLayer.shapeData;
    const options = `Edit shape properties:\n\n1. Change Color\n2. Change Weight\n${shapeData.type === 'circle' ? '3. Change Radius\n' : ''}0. Delete Shape`;
    
    const choice = prompt(options, '1');
    
    if (choice === '1') {
        editShapeColor(shapeLayer);
    } else if (choice === '2') {
        editShapeWeight(shapeLayer);
    } else if (choice === '3' && shapeData.type === 'circle') {
        editShapeRadius(shapeLayer);
    } else if (choice === '0') {
        deleteShape(shapeLayer);
    }
}

function editShapeColor(shapeLayer) {
    const currentColor = shapeLayer.shapeData.color;
    const newColor = prompt('Enter new color (hex format, e.g., #FF0000, #00FF00, #0000FF):', currentColor);
    
    if (newColor && /^#[0-9A-F]{6}$/i.test(newColor)) {
        shapeLayer.setStyle({
            color: newColor,
            fillColor: newColor
        });
        shapeLayer.shapeData.color = newColor;
        autoSaveMarkers();
    } else if (newColor) {
        alert('Invalid color format. Use hex format like #FF0000');
    }
}

function editShapeWeight(shapeLayer) {
    const currentWeight = shapeLayer.shapeData.weight;
    const newWeight = prompt('Enter new line weight (1-10):', currentWeight);
    
    if (newWeight && /^[1-9](\.[0-9])?$|^10$/.test(newWeight)) {
        const weight = parseFloat(newWeight);
        shapeLayer.setStyle({ weight: weight });
        shapeLayer.shapeData.weight = weight;
        autoSaveMarkers();
    } else if (newWeight) {
        alert('Invalid weight. Enter a number between 1 and 10');
    }
}

function editShapeRadius(shapeLayer) {
    const currentRadius = shapeLayer.shapeData.radius;
    const newRadius = prompt('Enter new radius (in meters):', Math.round(currentRadius));
    
    if (newRadius && /^[0-9]+$/.test(newRadius)) {
        const radius = parseInt(newRadius);
        shapeLayer.setRadius(radius);
        shapeLayer.shapeData.radius = radius;
        autoSaveMarkers();
    } else if (newRadius) {
        alert('Invalid radius. Enter a positive number');
    }
}

function deleteShape(shapeLayer) {
    if (confirm('Delete this shape?')) {
        map.removeLayer(shapeLayer);
        shapesArray = shapesArray.filter(s => s !== shapeLayer);
        autoSaveMarkers();  // Save after deletion
    }
}

function cancelDrawingShape() {
    isDrawingShape = false;
    currentShapeType = null;
    shapePoints = [];
    
    if (tempPolyline) {
        map.removeLayer(tempPolyline);
        tempPolyline = null;
    }
    
    const buttons = document.querySelectorAll('.draw-btn');
    buttons.forEach(btn => {
        btn.textContent = btn.dataset.originalText;
        btn.style.backgroundColor = '#555';
        btn.style.color = '#d0d5dd';
    });
    
    map._container.style.cursor = 'default';
}

function geolocateUser() {
    if (navigator.geolocation) {
        document.getElementById('geolocateBtn').textContent = '[LOC] Locating...';
        
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                
                // Remove previous user location marker
                if (userLocationMarker) {
                    map.removeLayer(userLocationMarker);
                }
                
                // Add new user location marker
                userLocationMarker = L.circleMarker([latitude, longitude], {
                    radius: 8,
                    fillColor: '#3498db',
                    color: '#2c3e50',
                    weight: 2,
                    opacity: 1,
                    fillOpacity: 0.7
                }).addTo(map);
                
                // Center map on user
                map.setView([latitude, longitude], 15);
                
                // Show popup
                userLocationMarker.bindPopup('Current GPS location').openPopup();
                
                document.getElementById('geolocateBtn').textContent = ' Locate Me';
            },
            (error) => {
                alert('Unable to get your location: ' + error.message);
                document.getElementById('geolocateBtn').textContent = ' Locate Me';
            }
        );
    } else {
        alert('Geolocation is not supported by your browser');
    }
}

// ============================================
// UI & Event Management
// ============================================

function enablePopupResize() {
    const popups = document.querySelectorAll('.marker-popup');
    
    popups.forEach(popup => {
        const handle = popup.querySelector('.popup-resize-handle');
        if (!handle || handle.classList.contains('resize-enabled')) return;
        
        handle.classList.add('resize-enabled');
        
        let isResizing = false;
        let startX = 0;
        let startY = 0;
        let startWidth = 0;
        let startHeight = 0;
        let resizeDirection = null;
        
        // Get the popup wrapper (parent container)
        const popupWrapper = popup.closest('.leaflet-popup-content-wrapper');
        if (!popupWrapper) return;
        
        // Helper function to detect which border was clicked
        const getResizeDirection = (e, element) => {
            const rect = element.getBoundingClientRect();
            const threshold = 10; // pixels from edge
            
            const distFromRight = rect.right - e.clientX;
            const distFromBottom = rect.bottom - e.clientY;
            
            let direction = '';
            if (distFromRight < threshold && distFromRight > 0) direction += 'e';
            if (distFromBottom < threshold && distFromBottom > 0) direction += 's';
            
            return direction || null;
        };
        
        // Resize handle mousedown
        handle.addEventListener('mousedown', (e) => {
            isResizing = true;
            resizeDirection = 'se';
            startX = e.clientX;
            startY = e.clientY;
            startWidth = popupWrapper.offsetWidth;
            startHeight = popupWrapper.offsetHeight;
            e.preventDefault();
            
            document.addEventListener('mousemove', resize);
            document.addEventListener('mouseup', stopResize);
        });
        
        // Border mousedown - drag any border to resize
        popupWrapper.addEventListener('mousedown', (e) => {
            if (e.target.closest('.marker-popup') && !e.target.closest('.popup-resize-handle')) {
                const direction = getResizeDirection(e, popupWrapper);
                if (direction) {
                    isResizing = true;
                    resizeDirection = direction;
                    startX = e.clientX;
                    startY = e.clientY;
                    startWidth = popupWrapper.offsetWidth;
                    startHeight = popupWrapper.offsetHeight;
                    e.preventDefault();
                    
                    document.addEventListener('mousemove', resize);
                    document.addEventListener('mouseup', stopResize);
                }
            }
        });
        
        const resize = (e) => {
            if (!isResizing || !resizeDirection) return;
            
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            
            let newWidth = startWidth;
            let newHeight = startHeight;
            
            // Handle width if dragging east (right edge)
            if (resizeDirection.includes('e')) {
                newWidth = Math.max(250, startWidth + deltaX);
            }
            
            // Handle height if dragging south (bottom edge)
            if (resizeDirection.includes('s')) {
                newHeight = Math.max(200, startHeight + deltaY);
            }
            
            popupWrapper.style.width = newWidth + 'px';
            popupWrapper.style.height = newHeight + 'px';
            
            // Force popup update
            if (map._popup) {
                map._popup.update();
            }
        };
        
        const stopResize = () => {
            isResizing = false;
            document.removeEventListener('mousemove', resize);
            document.removeEventListener('mouseup', stopResize);
        };
    });
}

function setupMapZoomListener() {
    map.on('zoomend', () => {
        currentZoom = map.getZoom();
        // Update all markers to new size
        markersArray.forEach(m => {
            const markerData = m.data;
            map.removeLayer(m.marker);
            const newMarker = L.marker([markerData.location[0], markerData.location[1]], {
                icon: createCustomIcon(markerData.icon)
            }).addTo(map);
            
            const popupContent = `
                <div class="marker-popup" data-marker-id="${markerData.id}">
                    <div class="popup-resize-handle"></div>
                    <div class="popup-title">${markerData.name}</div>
                    <div class="popup-description">${markerData.description.replace(/\n/g, '<br>')}</div>
                    <button class="popup-btn" onclick="editMarker(${markerData.id})">Edit</button>
                    <button class="popup-btn" onclick="deleteMarker(${markerData.id})">Delete</button>
                </div>
            `;
            
            newMarker.bindPopup(popupContent);
            newMarker.markerData = markerData;
            m.marker = newMarker;
        });
    });
}

function setupEventListeners() {
    // Map layer selector
    const mapLayerSelector = document.getElementById('mapLayerSelector');
    if (mapLayerSelector) {
        mapLayerSelector.addEventListener('change', (e) => {
            switchMapLayer(e.target.value);
        });
    }
    
    // Theme selector
    const themeSelector = document.getElementById('themeSelector');
    if (themeSelector) {
        themeSelector.addEventListener('change', (e) => {
            switchTheme(e.target.value);
        });
    }
    
    // Theme file input
    const themeFileInput = document.getElementById('themeFileInput');
    if (themeFileInput) {
        themeFileInput.addEventListener('change', loadCustomTheme);
    }
    
    // Search functionality
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');
    if (searchBtn) searchBtn.addEventListener('click', searchPlace);
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                searchPlace();
            }
        });
    }
    
    // Marker placement
    document.getElementById('confirmMarkerBtn').addEventListener('click', () => {
        const name = document.getElementById('markerName').value;
        const description = document.getElementById('markerDescription').value;
        const icon = document.getElementById('iconSelector').value;
        
        if (!name) {
            alert('Please enter a marker name');
            return;
        }
        
        isPlacingMarker = true;
        pendingMarkerData = { name, description, icon };
        document.getElementById('confirmMarkerBtn').textContent = 'Click on map to place...';
        document.getElementById('confirmMarkerBtn').style.backgroundColor = '#666';
    });
    
    // Shape drawing buttons
    document.getElementById('drawCircleBtn').addEventListener('click', () => startDrawingShape('circle'));
    document.getElementById('drawRectangleBtn').addEventListener('click', () => startDrawingShape('rectangle'));
    document.getElementById('drawPolygonBtn').addEventListener('click', () => startDrawingShape('polygon'));
    document.getElementById('finishShapeBtn').addEventListener('click', finishDrawingShape);
    document.getElementById('cancelShapeBtn').addEventListener('click', cancelDrawingShape);
    document.getElementById('clearShapesBtn').addEventListener('click', () => {
        if (confirm('Delete all shapes?')) {
            shapesArray.forEach(shape => map.removeLayer(shape));
            shapesArray = [];
        }
    });
    
    // Store original button text
    document.getElementById('drawCircleBtn').dataset.originalText = 'Draw Circle';
    document.getElementById('drawRectangleBtn').dataset.originalText = 'Draw Rectangle';
    document.getElementById('drawPolygonBtn').dataset.originalText = 'Draw Polygon';
    
    // Map click handler - handles both marker placement and shape drawing
    map.on('click', (e) => {
        if (isPlacingMarker && pendingMarkerData) {
            const { lat, lng } = e.latlng;
            addMarker(lat, lng, pendingMarkerData.name, pendingMarkerData.description, pendingMarkerData.icon);
            
            isPlacingMarker = false;
            document.getElementById('markerName').value = '';
            document.getElementById('markerDescription').value = '';
            document.getElementById('confirmMarkerBtn').textContent = 'Ready to Place';
            document.getElementById('confirmMarkerBtn').style.backgroundColor = '#555';
            
            autoSaveMarkers();
        } else if (isDrawingShape) {
            // Add point to shape
            shapePoints.push(e.latlng);
            
            // Show preview line for polygon/rectangle
            if (currentShapeType === 'polygon' || currentShapeType === 'rectangle') {
                if (tempPolyline) {
                    map.removeLayer(tempPolyline);
                }
                tempPolyline = L.polyline(shapePoints, {
                    color: '#3498db',
                    weight: 2,
                    dashArray: '5, 5'
                }).addTo(map);
            }
            
            // Add marker for each point
            L.circleMarker(e.latlng, {
                radius: 5,
                fillColor: '#3498db',
                color: '#2c3e50',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8
            }).addTo(map);
        }
    });
    
    // Right-click to finish drawing
    map.on('contextmenu', (e) => {
        if (isDrawingShape) {
            e.originalEvent.preventDefault();
            finishDrawingShape();
        }
    });
    
    // Data management buttons
    document.getElementById('saveDataBtn').addEventListener('click', saveMarkersToJSON);
    document.getElementById('loadDataBtn').addEventListener('click', () => {
        document.getElementById('fileInput').click();
    });
    document.getElementById('clearAllBtn').addEventListener('click', () => {
        if (confirm('Are you sure you want to delete all markers?')) {
            markersArray.forEach(m => map.removeLayer(m.marker));
            markersArray = [];
            updateMarkerList();
            autoSaveMarkers();
        }
    });
    
    // Geolocation button
    document.getElementById('geolocateBtn').addEventListener('click', geolocateUser);
    
    // File input handler
    document.getElementById('fileInput').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                loadMarkersFromJSON(event.target.result);
            };
            reader.readAsText(file);
        }
    });
    
    // TIF file input handler
    const tifFileInput = document.getElementById('tifFileInput');
    if (tifFileInput) {
        tifFileInput.addEventListener('change', handleTifUpload);
    }
}

function updateMarkerList() {
    const listContainer = document.getElementById('markerList');
    listContainer.innerHTML = '';
    
    if (markersArray.length === 0) {
        listContainer.innerHTML = '<p style="color: #888; text-align: center; font-size: 12px;">No markers yet</p>';
        return;
    }
    
    markersArray.forEach(m => {
        const item = document.createElement('div');
        item.className = 'marker-item';
        item.innerHTML = `
            <div class="marker-item-name">${m.data.name}</div>
            <div class="marker-item-coords">${m.data.location[0].toFixed(3)}, ${m.data.location[1].toFixed(3)}</div>
            <button onclick="deleteMarker(${m.data.id})" class="marker-item-delete">×</button>
        `;
        listContainer.appendChild(item);
    });
}

// ============================================
// Data Persistence
// ============================================

function saveMarkersToJSON() {
    // Prepare markers data
    const markersData = markersArray.map(m => m.data);
    
    // Prepare shapes data
    const shapesData = shapesArray.map(shape => ({
        type: shape.shapeData.type,
        center: shape.shapeData.center,
        bounds: shape.shapeData.bounds,
        points: shape.shapeData.points,
        radius: shape.shapeData.radius,
        color: shape.shapeData.color,
        weight: shape.shapeData.weight
    }));
    
    // Combine both into one object
    const data = {
        markers: markersData,
        shapes: shapesData
    };
    
    const json = JSON.stringify(data, null, 2);
    
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `map_data_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    alert('Markers and shapes saved successfully!');
}

function loadMarkersFromJSON(jsonString) {
    try {
        const data = JSON.parse(jsonString);
        
        // Clear existing markers
        markersArray.forEach(m => map.removeLayer(m.marker));
        markersArray = [];
        
        // Clear existing shapes
        shapesArray.forEach(shape => map.removeLayer(shape));
        shapesArray = [];
        
        // Load markers
        const markersToLoad = data.markers || data; // Support both new and old format
        markersToLoad.forEach(markerData => {
            addMarker(
                markerData.location[0],
                markerData.location[1],
                markerData.name,
                markerData.description,
                markerData.icon || 'default'
            );
        });
        
        // Load shapes if available
        if (data.shapes) {
            data.shapes.forEach(shapeData => {
                let shapeLayer = null;
                
                if (shapeData.type === 'circle') {
                    shapeLayer = L.circle(shapeData.center, shapeData.radius, {
                        color: shapeData.color,
                        weight: shapeData.weight,
                        fillColor: shapeData.color,
                        fillOpacity: 0.2
                    }).addTo(map);
                } else if (shapeData.type === 'rectangle') {
                    shapeLayer = L.rectangle(shapeData.bounds, {
                        color: shapeData.color,
                        weight: shapeData.weight,
                        fillColor: shapeData.color,
                        fillOpacity: 0.2
                    }).addTo(map);
                } else if (shapeData.type === 'polygon') {
                    shapeLayer = L.polygon(shapeData.points, {
                        color: shapeData.color,
                        weight: shapeData.weight,
                        fillColor: shapeData.color,
                        fillOpacity: 0.2
                    }).addTo(map);
                }
                
                if (shapeLayer) {
                    shapeLayer.shapeData = shapeData;
                    shapeLayer.on('click', () => showShapeContextMenu(shapeLayer));
                    shapesArray.push(shapeLayer);
                }
            });
        }
        
        alert('Markers and shapes loaded successfully!');
    } catch (error) {
        alert('Error loading data: ' + error.message);
    }
}

function loadMarkersFromStorage() {
    const stored = localStorage.getItem('mapMarkers');
    if (stored) {
        try {
            const data = JSON.parse(stored);
            
            // Handle both old format (array) and new format (object with markers/shapes)
            if (Array.isArray(data)) {
                // Old format - just markers
                data.forEach(markerData => {
                    addMarker(
                        markerData.location[0],
                        markerData.location[1],
                        markerData.name,
                        markerData.description,
                        markerData.icon || 'default'
                    );
                });
            } else if (data.markers) {
                // New format - markers and shapes
                data.markers.forEach(markerData => {
                    addMarker(
                        markerData.location[0],
                        markerData.location[1],
                        markerData.name,
                        markerData.description,
                        markerData.icon || 'default'
                    );
                });
                
                if (data.shapes) {
                    data.shapes.forEach(shapeData => {
                        let shapeLayer = null;
                        
                        if (shapeData.type === 'circle') {
                            shapeLayer = L.circle(shapeData.center, shapeData.radius, {
                                color: shapeData.color,
                                weight: shapeData.weight,
                                fillColor: shapeData.color,
                                fillOpacity: 0.2
                            }).addTo(map);
                        } else if (shapeData.type === 'rectangle') {
                            shapeLayer = L.rectangle(shapeData.bounds, {
                                color: shapeData.color,
                                weight: shapeData.weight,
                                fillColor: shapeData.color,
                                fillOpacity: 0.2
                            }).addTo(map);
                        } else if (shapeData.type === 'polygon') {
                            shapeLayer = L.polygon(shapeData.points, {
                                color: shapeData.color,
                                weight: shapeData.weight,
                                fillColor: shapeData.color,
                                fillOpacity: 0.2
                            }).addTo(map);
                        }
                        
                        if (shapeLayer) {
                            shapeLayer.shapeData = shapeData;
                            shapeLayer.on('click', () => showShapeContextMenu(shapeLayer));
                            shapesArray.push(shapeLayer);
                        }
                    });
                }
            }
        } catch (error) {
            console.log('No stored data or error loading them');
        }
    }
}

function autoSaveMarkers() {
    const markersData = markersArray.map(m => m.data);
    const shapesData = shapesArray.map(shape => ({
        type: shape.shapeData.type,
        center: shape.shapeData.center,
        bounds: shape.shapeData.bounds,
        points: shape.shapeData.points,
        radius: shape.shapeData.radius,
        color: shape.shapeData.color,
        weight: shape.shapeData.weight
    }));
    
    const data = {
        markers: markersData,
        shapes: shapesData
    };
    
    localStorage.setItem('mapMarkers', JSON.stringify(data));
}

// ============================================
// Start the application
// ============================================

window.addEventListener('DOMContentLoaded', initializeMap);

// ============================================
// Helper Functions for UI
// ============================================

/**
 * Update clock display with local and UTC time
 */
function updateClock() {
    const now = new Date();
    
    // Local time
    const localTime = now.toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    });
    
    // UTC time
    const utcTime = now.toISOString().split('T')[1].split('.')[0];
    
    const clockEl = document.getElementById('clock');
    if (clockEl) {
        clockEl.innerHTML = `<span class="local-time">${localTime}</span> <span class="utc-time">${utcTime}Z</span>`;
    }
}
setInterval(updateClock, 1000);
updateClock();

/**
 * Server status checking
 */
var serverStatus = 'checking';
var serverCheckInterval = null;

async function checkServerStatus() {
    const statusIndicator = document.querySelector('.status-indicator');
    const statusText = document.querySelector('.system-status span:nth-child(2)');
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/health`, {
            method: 'GET',
            timeout: 5000
        });
        
        if (response.ok) {
            const data = await response.json();
            serverStatus = 'online';
            if (statusIndicator) {
                statusIndicator.className = 'status-indicator online';
            }
            if (statusText) {
                statusText.textContent = 'SYS_ONLINE';
            }
        } else {
            serverStatus = 'error';
            if (statusIndicator) {
                statusIndicator.className = 'status-indicator error';
            }
            if (statusText) {
                statusText.textContent = 'SYS_ERROR';
            }
        }
    } catch (error) {
        serverStatus = 'offline';
        if (statusIndicator) {
            statusIndicator.className = 'status-indicator offline';
        }
        if (statusText) {
            statusText.textContent = 'SYS_OFFLINE';
        }
    }
}

// Check server status every 10 seconds
function startServerStatusCheck() {
    checkServerStatus();
    serverCheckInterval = setInterval(checkServerStatus, 10000);
}

// Start checking after DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startServerStatusCheck);
} else {
    startServerStatusCheck();
}

/**
 * Toggle grid overlay
 */
function toggleGrid() {
    const grid = document.getElementById('grid-overlay');
    if (grid) {
        grid.style.display = grid.style.display === 'block' ? 'none' : 'block';
    }
}

/**
 * Select all facility categories
 */
function selectAllCategories() {
    document.querySelectorAll('input[name="facility-category"]').forEach(cb => {
        cb.checked = true;
    });
    applyFacilityFilters();
}

/**
 * Get risk color by level
 */
function getRiskColor(riskLevel) {
    const colors = {
        'critical': '#d32f2f',    // Red
        'hazardous': '#f57c00',   // Orange
        'high': '#fbc02d',        // Yellow
        'medium': '#1976d2',      // Blue
        'low': '#388e3c',         // Green
        'CRITICAL': '#d32f2f',
        'HAZARDOUS': '#f57c00',
        'HIGH': '#fbc02d',
        'MEDIUM': '#1976d2',
        'LOW': '#388e3c'
    };
    return colors[riskLevel] || '#757575';
}

/**
 * Initialize Facilities Manager and update panel
 */
function initializeFacilitiesPanel() {
    // Initialize the facilities manager
    if (window.facilityManager) {
        updateFacilitiesPanel();
        console.log('[AEGIS] Facilities panel initialized');
    }
}

// Run after DOM is fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(initializeFacilitiesPanel, 500);
    });
} else {
    setTimeout(initializeFacilitiesPanel, 500);
}
/**
 * Copy text to clipboard with visual feedback
 */
function copyToClipboard(text, feedbackMessage = 'Copied!') {
    navigator.clipboard.writeText(text).then(() => {
        // Show feedback message
        const feedback = document.createElement('div');
        feedback.textContent = feedbackMessage;
        feedback.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #22c55e;
            color: white;
            padding: 10px 16px;
            border-radius: 4px;
            font-size: 12px;
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
        `;
        document.body.appendChild(feedback);
        
        // Add CSS animation if not already present
        if (!document.getElementById('copyFeedbackStyle')) {
            const style = document.createElement('style');
            style.id = 'copyFeedbackStyle';
            style.textContent = `
                @keyframes slideIn {
                    from {
                        transform: translateY(20px);
                        opacity: 0;
                    }
                    to {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }
                @keyframes slideOut {
                    from {
                        transform: translateY(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateY(20px);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        // Remove feedback after 2 seconds
        setTimeout(() => {
            feedback.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => feedback.remove(), 300);
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy to clipboard:', err);
    });
}

/**
 * Track mouse coordinates and make them clickable for copying
 */
map.on('mousemove', function(e) {
    const lat = e.latlng.lat.toFixed(5);
    const lng = e.latlng.lng.toFixed(5);
    const coordEl = document.getElementById('coordinates');
    if (coordEl) {
        const coordText = lat + ' / ' + lng;
        coordEl.innerText = coordText;
        coordEl.style.cursor = 'pointer';
        coordEl.title = 'Click to copy coordinates';
        coordEl.dataset.coords = coordText;
    }
});

/**
 * Copy coordinates when clicked
 */
document.addEventListener('click', function(e) {
    const coordEl = document.getElementById('coordinates');
    if (e.target === coordEl) {
        const coordText = coordEl.dataset.coords || coordEl.innerText;
        if (coordText) {
            copyToClipboard(coordText, 'Coordinates copied!');
        }
    }
});

/**
 * Track zoom level
 */
map.on('zoomend', function() {
    const zoomEl = document.getElementById('zoom-level');
    if (zoomEl) {
        zoomEl.innerText = 'Z: ' + map.getZoom();
    }
});