/**
 * AEGIS Facility Management UI
 * Client-side UI for managing detected facilities with offline support
 * Integrates with MI Fallout theme from NEXUS system
 */

class FacilityManager {
  constructor() {
    this.facilities = [];
    this.currentFacility = null;
    this.dbName = 'AEGIS_FacilitiesDB';
    this.storeName = 'facilities';
    this.inspectionsStore = 'inspections';
    this.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB;
    this.idbConnection = null;
    this.isSyncing = false;
    this.lastSync = localStorage.getItem('aegis_last_sync') || null;
    
    this.init();
  }

  /**
   * Initialize IndexedDB for offline support
   */
  async init() {
    try {
      await this.initIndexedDB();
      await this.loadFacilitiesFromCache();
      console.log('[FM] Facility Manager initialized with', this.facilities.length, 'cached facilities');
    } catch (error) {
      console.error('[FM] Initialization error:', error);
    }
  }

  /**
   * Initialize IndexedDB database
   */
  async initIndexedDB() {
    return new Promise((resolve, reject) => {
      const request = this.indexedDB.open(this.dbName, 1);

      request.onerror = () => {
        console.error('[FM] IndexedDB error:', request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        this.idbConnection = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          store.createIndex('category', 'category', { unique: false });
          store.createIndex('risk_level', 'risk_level', { unique: false });
          store.createIndex('status', 'status', { unique: false });
          store.createIndex('coordinates', ['latitude', 'longitude'], { unique: false });
        }

        if (!db.objectStoreNames.contains(this.inspectionsStore)) {
          const inspStore = db.createObjectStore(this.inspectionsStore, { keyPath: 'id' });
          inspStore.createIndex('facility_id', 'facility_id', { unique: false });
          inspStore.createIndex('date', 'inspection_date', { unique: false });
        }
      };
    });
  }

  /**
   * Save facility to IndexedDB (offline cache)
   */
  async saveFacilityToCache(facility) {
    return new Promise((resolve, reject) => {
      const transaction = this.idbConnection.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.put(facility);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(facility);
    });
  }

  /**
   * Load all facilities from IndexedDB cache
   */
  async loadFacilitiesFromCache() {
    return new Promise((resolve, reject) => {
      const transaction = this.idbConnection.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = store.getAll();

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.facilities = request.result;
        resolve(this.facilities);
      };
    });
  }

  /**
   * Get facility from cache by ID
   */
  async getFacilityFromCache(facilityId) {
    return new Promise((resolve, reject) => {
      const transaction = this.idbConnection.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = store.get(facilityId);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
    });
  }

  /**
   * Save inspection record
   */
  async saveInspection(inspection) {
    return new Promise((resolve, reject) => {
      const transaction = this.idbConnection.transaction([this.inspectionsStore], 'readwrite');
      const store = transaction.objectStore(this.inspectionsStore);
      const request = store.put(inspection);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(inspection);
    });
  }

  /**
   * Get inspections for facility
   */
  async getInspections(facilityId) {
    return new Promise((resolve, reject) => {
      const transaction = this.idbConnection.transaction([this.inspectionsStore], 'readonly');
      const store = transaction.objectStore(this.inspectionsStore);
      const index = store.index('facility_id');
      const request = index.getAll(facilityId);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result.sort((a, b) => 
        new Date(b.inspection_date) - new Date(a.inspection_date)
      ));
    });
  }

  /**
   * Push detected facilities to database
   */
  async pushDetectedFacilities(facilities) {
    try {
      // Save to cache first
      for (const fac of facilities) {
        await this.saveFacilityToCache(fac);
      }
      this.facilities = await this.loadFacilitiesFromCache();

      // Try to sync with server if online
      if (navigator.onLine) {
        await this.syncWithServer(facilities);
      }

      return { success: true, count: facilities.length };
    } catch (error) {
      console.error('[FM] Push facilities error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Sync facilities with server
   */
  async syncWithServer(facilities = null) {
    if (this.isSyncing) return;
    this.isSyncing = true;

    try {
      const toSync = facilities || this.facilities;

      // Push to server
      const pushResponse = await fetch('/api/facilities/bulk-import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ facilities: toSync })
      });

      if (!pushResponse.ok) {
        throw new Error('Sync push failed');
      }

      const pushResult = await pushResponse.json();
      console.log('[FM] Sync push completed:', pushResult);

      // Pull updates from server
      const pullResponse = await fetch(`/api/sync/pull?since=${this.lastSync || ''}`);
      if (pullResponse.ok) {
        const pullResult = await pullResponse.json();
        
        // Update local cache with server data
        for (const fac of pullResult.facilities) {
          await this.saveFacilityToCache(fac);
        }
        
        this.lastSync = new Date().toISOString();
        localStorage.setItem('aegis_last_sync', this.lastSync);
        
        console.log('[FM] Sync complete. Pulled', pullResult.count, 'facilities');
      }

      return { success: true, synced: pushResult.successful };
    } catch (error) {
      console.error('[FM] Sync error:', error);
      return { success: false, error: error.message };
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Export facilities as GeoJSON
   */
  async exportGeoJSON() {
    try {
      const response = await fetch('/api/facilities/export/geojson');
      if (!response.ok) {
        throw new Error('Export failed');
      }

      const geojson = await response.json();
      
      // Trigger download
      const blob = new Blob([JSON.stringify(geojson, null, 2)], { type: 'application/geo+json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `aegis-facilities-${new Date().toISOString().split('T')[0]}.geojson`;
      link.click();
      URL.revokeObjectURL(url);

      return { success: true };
    } catch (error) {
      console.error('[FM] Export error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get facilities filtered by category
   */
  async getFacilitiesByCategory(category) {
    return this.facilities.filter(f => f.category === category);
  }

  /**
   * Get facilities filtered by risk level
   */
  async getFacilitiesByRiskLevel(riskLevel) {
    return this.facilities.filter(f => f.risk_level === riskLevel);
  }

  /**
   * Get status summary
   */
  getStatusSummary() {
    const summary = {
      total: this.facilities.length,
      by_category: {},
      by_risk: {},
      by_status: {}
    };

    for (const fac of this.facilities) {
      summary.by_category[fac.category] = (summary.by_category[fac.category] || 0) + 1;
      summary.by_risk[fac.risk_level] = (summary.by_risk[fac.risk_level] || 0) + 1;
      summary.by_status[fac.status] = (summary.by_status[fac.status] || 0) + 1;
    }

    return summary;
  }
}

// Global instance
const facilityManager = new FacilityManager();

/**
 * Import detected facilities into database
 * Called after facility detection completes
 */
async function importDetectedFacilities(facilities) {
  if (!facilities || facilities.length === 0) return;

  try {
    // Transform facilities to db format
    const dbFacilities = facilities.map(f => ({
      id: facilityManager.generateFacilityId ? 
          facilityManager.generateFacilityId(f.latitude, f.longitude, f.name) :
          `FAC-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      name: f.name || f.categoryName,
      latitude: f.latitude,
      longitude: f.longitude,
      category: f.category,
      category_name: f.categoryName,
      risk_level: f.riskLevel,
      source: f.source,
      address: f.address,
      phone: f.phone,
      website: f.website,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      status: 'active'
    }));

    const result = await facilityManager.pushDetectedFacilities(dbFacilities);
    console.log('[FM] Import result:', result);

    // Update UI
    updateFacilitiesPanel();
    
    return result;
  } catch (error) {
    console.error('[FM] Import error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Update facilities panel in UI
 */
function updateFacilitiesPanel() {
  const panel = document.getElementById('panelFacilities');
  if (!panel) return;

  const summary = facilityManager.getStatusSummary();
  
  // Build HTML
  let html = `
    <div class="facilities-header">
      <h3>FACILITY DATABASE</h3>
      <div class="facilities-stats">
        <div class="stat-box">
          <div class="stat-label">TOTAL</div>
          <div class="stat-value">${summary.total}</div>
        </div>
  `;

  // Risk level stats
  for (const [level, count] of Object.entries(summary.by_risk)) {
    const color = getRiskColor(level);
    html += `
      <div class="stat-box">
        <div class="stat-label">${level.toUpperCase()}</div>
        <div class="stat-value" style="color: ${color}">${count}</div>
      </div>
    `;
  }

  html += `
      </div>
    </div>

    <div class="facilities-controls">
      <button class="fac-btn" onclick="facilityManager.syncWithServer()">SYNC</button>
      <button class="fac-btn" onclick="facilityManager.exportGeoJSON()">EXPORT</button>
      <button class="fac-btn" onclick="toggleFacilitiesFilter()">FILTER</button>
    </div>

    <div class="facilities-list" id="facilitiesList">
  `;

  // Facility items
  for (const fac of facilityManager.facilities.slice(0, 50)) {
    const riskColor = getRiskColor(fac.risk_level);
    html += `
      <div class="facility-item" onclick="selectFacility('${fac.id}')">
        <div class="fac-name">${fac.name}</div>
        <div class="fac-meta">
          <span class="fac-category">${fac.category_name}</span>
          <span class="fac-risk" style="color: ${riskColor}">${fac.risk_level}</span>
        </div>
        <div class="fac-coords">${fac.latitude.toFixed(4)}, ${fac.longitude.toFixed(4)}</div>
      </div>
    `;
  }

  if (facilityManager.facilities.length === 0) {
    html += '<div class="no-facilities">NO FACILITIES DETECTED</div>';
  }

  html += '</div>';

  panel.innerHTML = html;
}

/**
 * Select facility to view details
 */
async function selectFacility(facilityId) {
  const facility = await facilityManager.getFacilityFromCache(facilityId);
  if (!facility) return;

  facilityManager.currentFacility = facility;

  const panel = document.getElementById('facilityDetailPanel');
  if (!panel) return;

  const inspections = await facilityManager.getInspections(facilityId);
  
  let html = `
    <div class="detail-header">
      <h4>${facility.name}</h4>
      <button class="detail-close" onclick="document.getElementById('facilityDetailPanel').classList.remove('active')">×</button>
    </div>
    <div class="detail-content">
      <div class="detail-section">
        <label>CATEGORY</label>
        <div>${facility.category_name}</div>
      </div>
      <div class="detail-section">
        <label>RISK LEVEL</label>
        <div style="color: ${getRiskColor(facility.risk_level)}">${facility.risk_level}</div>
      </div>
      <div class="detail-section">
        <label>COORDINATES</label>
        <div>${facility.latitude.toFixed(6)}, ${facility.longitude.toFixed(6)}</div>
      </div>
      <div class="detail-section">
        <label>ADDRESS</label>
        <div>${facility.address || 'Not available'}</div>
      </div>
      <div class="detail-section">
        <label>SOURCE</label>
        <div>${facility.source}</div>
      </div>
      <div class="detail-section">
        <label>DETECTED</label>
        <div>${new Date(facility.created_at).toLocaleString()}</div>
      </div>

      <div class="detail-section">
        <label>INSPECTIONS (${inspections.length})</label>
        <div class="inspections-list">
  `;

  for (const insp of inspections) {
    html += `
      <div class="inspection-record">
        <div class="insp-date">${new Date(insp.inspection_date).toLocaleDateString()}</div>
        <div class="insp-status">${insp.status}</div>
        <div class="insp-hazard">Hazard: ${insp.hazard_level}</div>
      </div>
    `;
  }

  html += `
        </div>
      </div>

      <div class="detail-actions">
        <button class="action-btn" onclick="addInspectionRecord()">+ INSPECTION</button>
        <button class="action-btn" onclick="viewOnMap()">VIEW ON MAP</button>
      </div>
    </div>
  `;

  panel.innerHTML = html;
  panel.classList.add('active');
}

/**
 * Add inspection record for current facility
 */
function addInspectionRecord() {
  if (!facilityManager.currentFacility) return;

  const hazardLevel = prompt('Hazard Level (CRITICAL/HIGH/MEDIUM/LOW):', 'MEDIUM');
  const observations = prompt('Observations:');

  if (hazardLevel && observations) {
    const inspection = {
      id: `INS-${Date.now()}`,
      facility_id: facilityManager.currentFacility.id,
      inspection_date: new Date().toISOString(),
      status: 'COMPLETED',
      hazard_level: hazardLevel,
      observations: observations
    };

    facilityManager.saveInspection(inspection).then(() => {
      selectFacility(facilityManager.currentFacility.id);
    });
  }
}

/**
 * View facility on map
 */
function viewOnMap() {
  if (!facilityManager.currentFacility || !map) return;

  const fac = facilityManager.currentFacility;
  map.setView([fac.latitude, fac.longitude], 15);
  
  // Close detail panel
  document.getElementById('facilityDetailPanel')?.classList.remove('active');
}

/**
 * Toggle facilities filter
 */
function toggleFacilitiesFilter() {
  const filter = document.getElementById('facilitiesFilter');
  if (filter) {
    filter.classList.toggle('active');
  }
}

