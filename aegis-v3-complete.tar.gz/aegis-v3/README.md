# AEGIS V3 — Adaptive Emergency Geospatial Intelligence System

> Cascading Risk Analysis · Predictive Modelling · Emergency Response Support
> ISO 31000 · ISO 22301 · UNDRR Sendai Framework Aligned

---

## Architecture

```
aegis-v3/
├── index.html              Homepage — mode selection + project management wizard
├── app.html                Map application shell — project-scoped
├── homepage.js             Homepage controller (mode, project panel, wizard)
├── style-home.css          Homepage design system
├── server.js               Express backend — projects, OSM proxy, facility detection
├── facility-db-manager.js  SQLite adapter (per-project DB)
├── facility-detection.js   OSM/Places detection engine (V2, project-aware)
├── facilities-ui.js        Facility map UI (V2, project-aware)
├── script.js               Leaflet map engine (V2)
├── style.css               Map app styles (V2)
├── package.json
└── data/
    ├── projects.json       Project index (summary list)
    └── projects/
        └── {uuid}/
            ├── project.json    Full project metadata + area GeoJSON
            └── facilities.db   Project-specific SQLite facility DB
```

---

## Operating Modes

| Mode | Badge | DB | Description |
|---|---|---|---|
| **Simulation** | SIM | Isolated per-project | Sandboxed scenario design. No write-through to RA. |
| **Risk Analysis** | RA | Isolated per-project | Operational assessment. Persistent, authoritative data. |
| **Real-Time Mapping** | RT | — | Live feeds. *Coming soon.* |

Each project = 1 SQLite database. A project in SIM mode is entirely separate from the same area in RA mode, even if the boundary is identical.

---

## Setup

```bash
# Install dependencies
npm install

# Copy env template
cp .env.example .env
# Edit .env: add GOOGLE_PLACES_API_KEY if available (optional — Overpass works without it)

# Start server
npm start          # production
npm run dev        # development (nodemon)
```

Navigate to `http://localhost:3001` → Homepage loads.

---

## Project Flow

```
Homepage → Select Mode (SIM / RA)
         → Project Panel slides in
         → New Project → Wizard:
             Step 1: Name + Description
             Step 2: Area Definition
                  ├── Upload: .geojson | .zip (SHP) | .kml
                  └── OSM Search: City → optional district drill-down
             Step 3: Review → Create
         → app.html?project={uuid} loads
         → Map scoped to project boundary
         → Facility detection runs (once/day, cached in project DB)
```

---

## API Endpoints

### Project Management
| Method | Path | Description |
|---|---|---|
| GET | `/api/projects?mode=` | List projects (filterable by mode) |
| POST | `/api/projects` | Create project |
| GET | `/api/projects/:id` | Get full project metadata |
| PUT | `/api/projects/:id` | Update project |
| DELETE | `/api/projects/:id` | Delete project + DB |

### OSM / Boundary
| Method | Path | Description |
|---|---|---|
| GET | `/api/osm/search?q=&limit=` | Nominatim city search (proxied) |
| GET | `/api/osm/boundary/:type/:id` | Fetch boundary polygon |
| POST | `/api/osm/districts` | Fetch sub-admin districts (Overpass) |

### Facility Detection (V2 compat)
| Method | Path | Description |
|---|---|---|
| POST | `/api/detect-facilities` | Detect facilities in bounds (+ `projectId` to persist) |
| GET | `/api/health` | System health + project count |

---

## File Format Support (Area Upload)

| Format | Extension | Parser |
|---|---|---|
| GeoJSON | `.geojson` `.json` | Native `JSON.parse` |
| Shapefile | `.zip` (containing .shp .dbf .prj) | `shpjs` (CDN) |
| KML | `.kml` | Native DOMParser |

---

## Roadmap

- [ ] Grid/district subdivision with configurable cell size
- [ ] UUID labelling with type/subset taxonomy
- [ ] Once-per-day API schedule with DB cache check
- [ ] Dependency graph engine (cascading failure modelling)
- [ ] Risk index calculation (ISO 31000 aligned)
- [ ] Scenario builder for Simulation mode
- [ ] Real-Time Mapping module
- [ ] Export: PDF reports, GeoJSON, CSV
