/**
 * Critical Facilities Detection Frontend Module
 * Integrates with backend API to detect and display facilities on Leaflet map
 * Features: Auto-translation, Risk-based classification, GeoJSON export, Risk reports
 */

// ============================================
// Facility Detection State
// ============================================

// Auto-detect backend URL based on environment
const BACKEND_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'http://localhost:3001'
    : window.location.origin;

var facilitiesState = {
  backendUrl: BACKEND_URL,
  facilities: [],
  markers: {},
  filters: {
    categories: [],
    riskLevels: ['critical', 'hazardous', 'high', 'medium', 'low'],
    sources: ['google_places', 'osm_overpass']
  },
  options: {
    autoDetect: true,
    autoDetectOnMove: true,
    maxResults: 100
  },
  isDetecting: false,
  categories: [],
  translationCache: {}
};

// ============================================
// Facility Marker Styling
// ============================================

/**
 * Get marker color based on risk level
 */
function getRiskColor(riskLevel) {
  const colors = {
    'critical': '#d32f2f',    // Red
    'hazardous': '#f57c00',   // Orange
    'high': '#fbc02d',        // Yellow
    'medium': '#1976d2',      // Blue
    'low': '#388e3c'          // Green
  };
  return colors[riskLevel] || '#757575';
}

/**
 * Create facility marker icon
 */
function createFacilityMarkerIcon(riskLevel) {
  const color = getRiskColor(riskLevel);
  const size = 32;
  
  return L.divIcon({
    className: 'facility-marker',
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        border: 3px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        font-weight: bold;
        color: white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.4);
        cursor: pointer;
      ">!</div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2]
  });
}

/**
 * Get category symbol for facility (text-based, no emoji)
 */
function getCategoryEmoji(categoryId) {
  const symbols = {
    hospital: '[H]',
    clinic: '[C]',
    fire_station: '[F]',
    police: '[P]',
    school: '[S]',
    gymnasium: '[G]',
    shelter: '[SH]',
    power_plant: '[PW]',
    substation: '[SB]',
    chemical_plant: '[CH]',
    petroleum: '[OL]',
    waste: '[W]',
    water: '[WR]',
    airport: '[A]',
    train_station: '[T]',
    water_supply: '[WS]',
    communication: '[CM]'
  };
  return symbols[categoryId] || '[*]';
}

// ============================================
// Language Detection & Translation
// ============================================

/**
 * Check if a text string contains non-ASCII (non-English) characters.
 * Used to decide whether translation is needed regardless of coordinates.
 */
function textNeedsTranslation(text) {
  if (!text) return false;
  // Matches any character outside basic ASCII printable range
  // This catches CJK, Cyrillic, Arabic, Thai, Devanagari, Greek, etc.
  return /[^\x00-\x7F]/.test(text);
}

/**
 * Detect language hint based on coordinates (country/region).
 * This is only a hint — the backend translation API auto-detects the real language.
 * Returns 'auto' for regions not explicitly listed so translation is still attempted.
 */
function detectLanguageFromCoordinates(lat, lng) {
  // Coordinate-based language hints (non-exhaustive, used only as fallback hint)
  if (lat >= 21.9 && lat <= 25.3 && lng >= 120 && lng <= 122) return 'zh-TW';  // Taiwan
  if (lat >= 18 && lat <= 54 && lng >= 73 && lng <= 135) return 'zh-CN';       // China
  if (lat >= 24 && lat <= 46 && lng >= 123 && lng <= 154) return 'ja';         // Japan
  if (lat >= 33 && lat <= 39 && lng >= 124 && lng <= 132) return 'ko';         // South Korea
  if (lat >= -34 && lat <= 5 && lng >= -74 && lng <= -34) return 'pt';         // Brazil
  if (lat >= 36 && lat <= 44 && lng >= -10 && lng <= 4) return 'es';           // Spain
  if (lat >= 14 && lat <= 33 && lng >= -118 && lng <= -86) return 'es';        // Mexico
  if (lat >= 41 && lat <= 51 && lng >= -5 && lng <= 10) return 'fr';           // France
  if (lat >= 47 && lat <= 55 && lng >= 5 && lng <= 16) return 'de';            // Germany
  if (lat >= 41 && lat <= 82 && lng >= 19 && lng <= 180) return 'ru';          // Russia
  if (lat >= 12 && lat <= 42 && lng >= 34 && lng <= 63) return 'ar';           // Middle East
  if (lat >= 5 && lat <= 21 && lng >= 97 && lng <= 106) return 'th';           // Thailand
  if (lat >= 8 && lat <= 24 && lng >= 102 && lng <= 110) return 'vi';          // Vietnam
  if (lat >= 6 && lat <= 37 && lng >= 68 && lng <= 97) return 'hi';            // India
  if (lat >= -11 && lat <= 6 && lng >= 95 && lng <= 141) return 'id';          // Indonesia
  if (lat >= 36 && lat <= 42 && lng >= 26 && lng <= 45) return 'tr';           // Turkey
  if (lat >= 34 && lat <= 42 && lng >= 19 && lng <= 30) return 'el';           // Greece
  if (lat >= 36 && lat <= 47 && lng >= 6 && lng <= 19) return 'it';            // Italy
  if (lat >= 36 && lat <= 44 && lng >= 20 && lng <= 30) return 'ro';           // Romania
  if (lat >= 49 && lat <= 55 && lng >= 14 && lng <= 24) return 'pl';           // Poland
  if (lat >= 46 && lat <= 49 && lng >= 16 && lng <= 23) return 'hu';           // Hungary
  if (lat >= 55 && lat <= 70 && lng >= 4 && lng <= 31) return 'sv';            // Scandinavia
  // Default: let the translation API auto-detect the language
  return 'auto';
}

/**
 * Translate facility name using backend API.
 * sourceLang can be 'auto' to let the backend auto-detect.
 */
async function translateText(text, sourceLang = 'auto', targetLang = 'en') {
  // Skip if text is empty or already plain ASCII English
  if (!text || !textNeedsTranslation(text)) return text;
  
  const cacheKey = `${text}`;
  if (facilitiesState.translationCache[cacheKey]) {
    return facilitiesState.translationCache[cacheKey];
  }
  
  try {
    const response = await axios.post(`${facilitiesState.backendUrl}/api/translate`, {
      text,
      sourceLang,
      targetLang
    }, { timeout: 8000 });
    
    const translated = response.data.translatedText || text;
    facilitiesState.translationCache[cacheKey] = translated;
    return translated;
  } catch (error) {
    console.warn('[TRANSLATE] Failed for "' + text + '":', error.message);
    return text;
  }
}

/**
 * Auto-classify facility based on translated name.
 * Uses word-boundary matching to avoid false positives.
 * Only overrides the backend category if a strong keyword match is found;
 * otherwise preserves the original category from OSM tags / Google types.
 */
function classifyFacilityFromName(translatedName, originalCategory) {
  const nameLower = translatedName.toLowerCase();
  
  // Helper: match whole words only (prevents 'fire' matching 'firestone', 'oil' matching 'soil')
  function hasWord(word) {
    return new RegExp('\\b' + word + '\\b', 'i').test(nameLower);
  }
  function hasAnyWord(words) {
    return words.some(w => hasWord(w));
  }
  
  // Medical facilities — require specific medical terms
  if (hasAnyWord(['hospital', 'clinic', 'infirmary', 'medical center', 'medical centre'])) {
    return { category: 'hospital', categoryName: 'Hospital/Clinic', riskLevel: 'critical' };
  }
  
  // Emergency services — require full compound terms where possible
  if (hasAnyWord(['fire station', 'fire department', 'fire brigade', 'fire hall'])) {
    return { category: 'fire_station', categoryName: 'Fire Station', riskLevel: 'critical' };
  }
  if (hasAnyWord(['police station', 'police department', 'police headquarters', 'gendarmerie'])) {
    return { category: 'police', categoryName: 'Police Station', riskLevel: 'high' };
  }
  
  // Education — require specific education terms
  if (hasAnyWord(['school', 'university', 'college', 'lycee', 'lycée', 'akademie', 'academy'])) {
    return { category: 'school', categoryName: 'School/University', riskLevel: 'high' };
  }
  
  // Power & energy
  if (hasAnyWord(['power plant', 'power station', 'substation', 'transformer station',
                   'electric plant', 'electricity station', 'nuclear plant', 'thermal plant'])) {
    return { category: 'power_plant', categoryName: 'Power/Electric', riskLevel: 'critical' };
  }
  
  // Chemical & industrial — use compound terms to avoid false positives
  if (hasAnyWord(['chemical plant', 'chemical factory', 'refinery', 'petroleum',
                   'oil refinery', 'oil depot', 'gas plant', 'petrochemical'])) {
    return { category: 'chemical_plant', categoryName: 'Chemical/Petroleum', riskLevel: 'hazardous' };
  }
  
  // Water facilities — require specific water infrastructure terms
  if (hasAnyWord(['water treatment', 'water plant', 'sewage', 'wastewater',
                   'water supply', 'desalination', 'water tower', 'reservoir'])) {
    return { category: 'water_treatment', categoryName: 'Water Treatment', riskLevel: 'high' };
  }
  
  // Waste management
  if (hasAnyWord(['landfill', 'waste facility', 'waste transfer', 'recycling plant',
                   'waste treatment', 'incinerator'])) {
    return { category: 'waste', categoryName: 'Waste Facility', riskLevel: 'hazardous' };
  }
  
  // Transportation
  if (hasAnyWord(['airport', 'airfield', 'aerodrome', 'airbase'])) {
    return { category: 'airport', categoryName: 'Airport', riskLevel: 'critical' };
  }
  if (hasAnyWord(['train station', 'railway station', 'subway station', 'metro station',
                   'rail terminal', 'central station'])) {
    return { category: 'train_station', categoryName: 'Train/Metro Station', riskLevel: 'high' };
  }
  
  // Telecom
  if (hasAnyWord(['telecom tower', 'communication tower', 'cell tower', 'radio mast'])) {
    return { category: 'communication', categoryName: 'Telecom Tower', riskLevel: 'medium' };
  }
  
  // Shelter
  if (hasAnyWord(['shelter', 'community center', 'community centre', 'evacuation center',
                   'evacuation centre', 'refugee camp'])) {
    return { category: 'shelter', categoryName: 'Shelter/Community Center', riskLevel: 'high' };
  }
  
  // No strong keyword match — preserve the original backend category
  return { 
    category: originalCategory, 
    categoryName: originalCategory ? originalCategory.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'Unknown',
    riskLevel: null  // null signals: do NOT override the backend's risk level
  };
}

/**
 * Process facility with automatic translation and classification.
 * 
 * Strategy:
 * 1. Always attempt translation if the name contains non-ASCII characters
 *    (language is auto-detected by the backend, not just coordinates).
 * 2. After translation, try to refine the category via keyword matching.
 * 3. Only override the backend's category/riskLevel when keyword matching
 *    finds a strong match. Otherwise, trust the OSM tag / Google type.
 */
async function processFacilityWithTranslation(facility) {
  // Get a language hint from coordinates (used as fallback hint only)
  const langHint = detectLanguageFromCoordinates(facility.latitude, facility.longitude);
  
  // Determine if the name needs translation (non-ASCII characters present)
  const needsTranslation = textNeedsTranslation(facility.name);
  
  let nameForClassification = facility.name;
  
  if (needsTranslation) {
    try {
      const translatedName = await translateText(facility.name, langHint, 'en');
      
      // Only update if translation actually changed the text
      if (translatedName && translatedName !== facility.name) {
        facility.originalName = facility.name;
        facility.translatedName = translatedName;
        facility.name = translatedName;
        facility.detectedLanguage = langHint;
        nameForClassification = translatedName;
        console.log(`[TRANSLATE] ${facility.originalName} → ${translatedName}`);
      }
    } catch (error) {
      console.warn('[TRANSLATE] Error processing facility:', error.message);
      // Keep original name; classification will use it as-is
    }
  }
  
  // Try to refine classification from the (possibly translated) name
  const classification = classifyFacilityFromName(nameForClassification, facility.category);
  
  // Only override backend category if keyword matching found a strong match
  // (classification.riskLevel === null means no strong match was found)
  if (classification.riskLevel !== null) {
    facility.category = classification.category;
    facility.categoryName = classification.categoryName;
    facility.riskLevel = classification.riskLevel;
  }
  // Otherwise, preserve the category and riskLevel already set by the backend
  
  return facility;
}

// ============================================
// Backend Communication
// ============================================

/**
 * Query backend for facilities within map bounds
 */
async function detectFacilities() {
  if (facilitiesState.isDetecting) return;
  
  facilitiesState.isDetecting = true;
  const btn = document.getElementById('detectFacilitiesBtn');
  if (btn) btn.style.opacity = '0.5';
  
  try {
    // Get current map bounds
    const bounds = map.getBounds();
    const queryBounds = {
      north: bounds.getNorth(),
      south: bounds.getSouth(),
      east: bounds.getEast(),
      west: bounds.getWest()
    };
    
    console.log('[DETECT] Querying bounds - please wait (30s timeout):', queryBounds);
    
    // Call backend API with longer timeout for Overpass
    const response = await axios.post(`${facilitiesState.backendUrl}/api/detect-facilities`, {
      bounds: queryBounds,
      filters: facilitiesState.filters,
      options: facilitiesState.options
    }, {
      timeout: 35000  // Give server 35s to complete
    });
    
    if (response.data.facilities) {
      facilitiesState.facilities = response.data.facilities;
      displayFacilities(response.data.facilities);
      
      console.log(`[SUCCESS] Found ${response.data.facilities.length} facilities`);
      console.log(`  - Google Places: ${response.data.metadata.googlePlacesCount}`);
      console.log(`  - OSM/Overpass: ${response.data.metadata.osmCount}`);
      
      // Update UI
      updateFacilityStats(response.data);
      
      // Import to database if facility manager is available
      if (window.facilityManager && response.data.facilities.length > 0) {
        console.log('[DETECT] Importing facilities to database...');
        try {
          await importDetectedFacilities(response.data.facilities);
          console.log('[SUCCESS] Facilities imported to database');
        } catch (err) {
          console.error('[ERROR] Failed to import facilities:', err);
        }
      }
    }
  } catch (error) {
    console.error('[ERROR] Detection failed:', error.message);
    if (error.code === 'ECONNABORTED') {
      alert('Query timeout - map area too large. Please zoom in and try again.');
    } else {
      alert(`Error: ${error.response?.data?.error || error.message}`);
    }
  } finally {
    facilitiesState.isDetecting = false;
    if (btn) btn.style.opacity = '1';
  }
}

/**
 * Load available facility categories from backend
 */
async function loadFacilityCategories() {
  try {
    const response = await axios.get(`${facilitiesState.backendUrl}/api/facility-categories`);
    facilitiesState.categories = response.data;
    console.log('[SUCCESS] Loaded facility categories:', facilitiesState.categories.length);
  } catch (error) {
    console.error('Error loading facility categories:', error);
  }
}

// ============================================
// Facility Display & Markers
// ============================================

/**
 * Display facilities on map with markers and popups
 */
async function displayFacilities(facilities) {
  // Clear existing facility markers
  clearFacilityMarkers();
  
  // Process facilities with translation (in batches to avoid overwhelming the server)
  const batchSize = 10;
  for (let i = 0; i < facilities.length; i += batchSize) {
    const batch = facilities.slice(i, i + batchSize);
    await Promise.all(batch.map(f => processFacilityWithTranslation(f)));
  }
  
  facilities.forEach(facility => {
    const markerId = `facility_${facility.id}`;
    
    // Create marker
    const marker = L.marker(
      [facility.latitude, facility.longitude],
      { icon: createFacilityMarkerIcon(facility.riskLevel) }
    ).addTo(map);
    
    // Create detailed popup
    const popupContent = createFacilityPopup(facility);
    marker.bindPopup(popupContent);
    
    // Store marker reference
    facilitiesState.markers[markerId] = marker;
    
    // Click to pan
    marker.on('click', () => {
      map.setView([facility.latitude, facility.longitude], Math.max(map.getZoom(), 14));
    });
  });
  
  console.log(`[PLOT] Plotted ${facilities.length} facility markers`);
}

/**
 * Copy text to clipboard with visual feedback
 */
function copyFacilityCoords(lat, lng) {
  const coordsText = lat.toFixed(6) + ', ' + lng.toFixed(6);
  const feedback = document.createElement('div');
  feedback.textContent = 'Coordinates copied!';
  feedback.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #22c55e;
    color: white;
    padding: 10px 16px;
    border-radius: 4px;
    font-size: 12px;
    z-index: 10000;
    animation: slideIn 0.3s ease-out;
  `;
  document.body.appendChild(feedback);
  
  navigator.clipboard.writeText(coordsText).then(() => {
    setTimeout(() => {
      feedback.style.animation = 'slideOut 0.3s ease-out';
      setTimeout(() => feedback.remove(), 300);
    }, 2000);
  });
}

/**
 * Create detailed popup HTML for facility
 */
function createFacilityPopup(facility) {
  const emoji = getCategoryEmoji(facility.category);
  const riskBg = getRiskColor(facility.riskLevel);
  const coordsText = facility.latitude.toFixed(6) + ', ' + facility.longitude.toFixed(6);
  
  return `
    <div class="facility-popup" style="min-width: 280px;">
      <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">
        <span style="font-size: 24px;">${emoji}</span>
        <div style="flex: 1;">
          <div style="font-weight: bold; font-size: 14px;">
            ${facility.name}
          </div>
          ${facility.originalName ? `<div style="font-size: 11px; color: #999; font-style: italic;">(${facility.originalName})</div>` : ''}
          ${facility.detectedLanguage ? `<div style="font-size: 10px; color: #999;">Detected: ${facility.detectedLanguage}</div>` : ''}
          <div style="font-size: 12px; color: #666;">${facility.categoryName}</div>
        </div>
      </div>
      
      <div style="border-top: 1px solid #ddd; padding-top: 8px; margin-bottom: 8px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
          <div>
            <strong>Risk Level:</strong><br>
            <span style="background: ${riskBg}; color: white; padding: 2px 6px; border-radius: 3px; text-transform: uppercase; font-weight: bold;">
              ${facility.riskLevel}
            </span>
          </div>
          <div>
            <strong>Source:</strong><br>
            <span style="font-size: 11px;">${facility.source === 'google_places' ? 'GOOGLE' : 'OSM'}</span>
          </div>
        </div>
      </div>
      
      <div style="border-top: 1px solid #ddd; padding-top: 8px; margin-bottom: 8px;">
        <div style="font-size: 12px;">
          <strong>Coordinates:</strong><br>
          <div style="cursor: pointer; padding: 4px 6px; background: rgba(0,0,0,0.1); border-radius: 3px; margin-top: 4px; font-family: monospace; font-size: 11px;" onclick="copyFacilityCoords(${facility.latitude}, ${facility.longitude})" title="Click to copy">
            [LOC] ${coordsText}
          </div>
        </div>
        ${facility.address ? `<div style="font-size: 12px; margin-top: 4px; color: #666;"><strong>Address:</strong><br>${facility.address}</div>` : ''}
      </div>
      
      <div style="border-top: 1px solid #ddd; padding-top: 8px;">
        <div style="font-size: 12px;">
          <strong>Risk Exposure:</strong><br>
          <div style="margin-top: 4px;">
            Priority: <strong>${facility.exposure.priorityScore}</strong> | 
            Risk: <strong>${facility.exposure.riskScore}</strong>
          </div>
          <div style="margin-top: 4px; font-size: 11px; color: #666;">
            <strong>Vulnerabilities:</strong><br>
            ${facility.exposure.vulnerabilityIndicators.join(', ')}
          </div>
        </div>
      </div>
      
      <div style="margin-top: 8px; text-align: center; font-size: 11px; color: #999;">
        ID: ${facility.id}
      </div>
    </div>
  `;
}

/**
 * Clear all facility markers from map
 */
function clearFacilityMarkers() {
  Object.values(facilitiesState.markers).forEach(marker => {
    map.removeLayer(marker);
  });
  facilitiesState.markers = {};
}

// ============================================
// Filter & Control Panel
// ============================================

/**
 * Update facility statistics display
 */
function updateFacilityStats(data) {
  const statsDiv = document.getElementById('facilityStats');
  if (!statsDiv) return;
  
  const byCategoryCount = {};
  const byRiskCount = {};
  
  data.facilities.forEach(f => {
    byCategoryCount[f.categoryName] = (byCategoryCount[f.categoryName] || 0) + 1;
    byRiskCount[f.riskLevel] = (byRiskCount[f.riskLevel] || 0) + 1;
  });
  
  let html = `
    <div style="font-size: 12px; padding: 8px; background: #f5f5f5; border-radius: 4px;">
      <strong>Facilities Detected: ${data.count}</strong><br>
      <div style="margin-top: 6px; font-size: 11px;">
  `;
  
  Object.entries(byRiskCount).forEach(([risk, count]) => {
    const color = getRiskColor(risk);
    html += `
      <div style="margin: 2px 0;">
        <span style="background: ${color}; color: white; padding: 1px 4px; border-radius: 2px; font-weight: bold;">
          ${risk.toUpperCase()}
        </span>: ${count}
      </div>
    `;
  });
  
  html += '</div></div>';
  statsDiv.innerHTML = html;
}

/**
 * Apply filters and refresh display
 */
function applyFacilityFilters() {
  const selectedCategories = Array.from(document.querySelectorAll('input[name="facility-category"]:checked'))
    .map(cb => cb.value);
  const selectedRisks = Array.from(document.querySelectorAll('input[name="facility-risk"]:checked'))
    .map(cb => cb.value);
  
  facilitiesState.filters.categories = selectedCategories;
  facilitiesState.filters.riskLevels = selectedRisks;
  
  // Re-detect with new filters
  detectFacilities();
}

// ============================================
// Auto-Detection on Map Move
// ============================================

/**
 * Setup auto-detection when map bounds change
 */
function setupAutoFacilityDetection() {
  if (!facilitiesState.options.autoDetectOnMove) return;
  
  let detectionTimeout;
  map.on('moveend', () => {
    // Debounce: wait for map to settle before detecting
    clearTimeout(detectionTimeout);
    detectionTimeout = setTimeout(() => {
      if (facilitiesState.options.autoDetect) {
        detectFacilities();
      }
    }, 1000);
  });
}

// ============================================
// Integration with Main Application
// ============================================

/**
 * Initialize facility detection module
 * Call this after Leaflet map is ready
 */
function initializeFacilityDetection() {
  console.log('[INIT] Initializing Critical Facilities Detection...');
  
  // Load categories from backend
  loadFacilityCategories();
  
  // Setup auto-detection
  setupAutoFacilityDetection();
  
  console.log('[SUCCESS] Facility detection module ready');
}

/**
 * Toggle facility auto-detection
 */
function toggleFacilityAutoDetect() {
  facilitiesState.options.autoDetect = !facilitiesState.options.autoDetect;
  const btn = document.getElementById('autoDetectToggle');
  if (btn) {
    btn.textContent = facilitiesState.options.autoDetect ? ' Auto-Detect ON' : ' Auto-Detect OFF';
    btn.style.background = facilitiesState.options.autoDetect ? '#4CAF50' : '#999';
  }
}

/**
 * Export facilities as GeoJSON
 */
function exportFacilitiesAsGeoJSON() {
  const geojson = {
    type: 'FeatureCollection',
    features: facilitiesState.facilities.map(f => ({
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [f.longitude, f.latitude]
      },
      properties: {
        id: f.id,
        name: f.name,
        category: f.category,
        categoryName: f.categoryName,
        riskLevel: f.riskLevel,
        source: f.source,
        address: f.address,
        priorityScore: f.exposure.priorityScore,
        vulnerabilities: f.exposure.vulnerabilityIndicators
      }
    }))
  };
  
  // Download as JSON file
  const blob = new Blob([JSON.stringify(geojson, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `facilities_${new Date().toISOString().split('T')[0]}.geojson`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  console.log(`[EXPORT] Exported ${facilitiesState.facilities.length} facilities as GeoJSON`);
}

// ============================================
// Risk Analysis Report
// ============================================

/**
 * Generate risk analysis report for detected facilities
 */
function generateRiskAnalysisReport() {
  const report = {
    timestamp: new Date().toISOString(),
    totalFacilities: facilitiesState.facilities.length,
    summaryByRisk: {},
    summaryByCategory: {},
    topPriorityFacilities: [],
    vulnerabilityMap: {}
  };
  
  // Summary by risk level
  facilitiesState.facilities.forEach(f => {
    if (!report.summaryByRisk[f.riskLevel]) {
      report.summaryByRisk[f.riskLevel] = { count: 0, facilities: [] };
    }
    report.summaryByRisk[f.riskLevel].count += 1;
    report.summaryByRisk[f.riskLevel].facilities.push(f.name);
  });
  
  // Summary by category
  facilitiesState.facilities.forEach(f => {
    if (!report.summaryByCategory[f.categoryName]) {
      report.summaryByCategory[f.categoryName] = { count: 0, riskLevels: {} };
    }
    report.summaryByCategory[f.categoryName].count += 1;
    if (!report.summaryByCategory[f.categoryName].riskLevels[f.riskLevel]) {
      report.summaryByCategory[f.categoryName].riskLevels[f.riskLevel] = 0;
    }
    report.summaryByCategory[f.categoryName].riskLevels[f.riskLevel] += 1;
  });
  
  // Top priority facilities
  report.topPriorityFacilities = facilitiesState.facilities
    .sort((a, b) => b.exposure.priorityScore - a.exposure.priorityScore)
    .slice(0, 10)
    .map(f => ({
      name: f.name,
      category: f.categoryName,
      riskLevel: f.riskLevel,
      priorityScore: f.exposure.priorityScore,
      vulnerabilities: f.exposure.vulnerabilityIndicators
    }));
  
  // Vulnerability map
  facilitiesState.facilities.forEach(f => {
    f.exposure.vulnerabilityIndicators.forEach(vuln => {
      if (!report.vulnerabilityMap[vuln]) {
        report.vulnerabilityMap[vuln] = { count: 0, facilities: [] };
      }
      report.vulnerabilityMap[vuln].count += 1;
      report.vulnerabilityMap[vuln].facilities.push(f.name);
    });
  });
  
  return report;
}

/**
 * Display risk analysis report and download as JSON or TXT
 */
function showRiskAnalysisReport() {
  const report = generateRiskAnalysisReport();
  
  // Create HTML for display
  let html = `
    <div style="font-size: 12px; max-height: 500px; overflow-y: auto; padding: 12px; background: white; border-radius: 4px;">
      <h3 style="margin-top: 0;">Risk Analysis Report</h3>
      <p><strong>Timestamp:</strong> ${report.timestamp}</p>
      <p><strong>Total Facilities:</strong> ${report.totalFacilities}</p>
      
      <h4>By Risk Level</h4>
      <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
        <tr style="border-bottom: 1px solid #ddd;">
          <th style="text-align: left; padding: 4px;">Risk Level</th>
          <th style="text-align: center; padding: 4px;">Count</th>
        </tr>
  `;
  
  Object.entries(report.summaryByRisk).forEach(([risk, data]) => {
    html += `
      <tr style="border-bottom: 1px solid #eee;">
        <td style="padding: 4px;"><span style="background: ${getRiskColor(risk)}; color: white; padding: 2px 6px; border-radius: 2px; font-weight: bold;">${risk.toUpperCase()}</span></td>
        <td style="text-align: center; padding: 4px;">${data.count}</td>
      </tr>
    `;
  });
  
  html += `
      </table>
      
      <h4 style="margin-top: 12px;">Top Priority Facilities</h4>
      <div style="max-height: 200px; overflow-y: auto;">
  `;
  
  report.topPriorityFacilities.forEach((f, idx) => {
    html += `
      <div style="padding: 6px; background: #f5f5f5; margin-bottom: 4px; border-left: 3px solid ${getRiskColor(f.riskLevel)};">
        <div><strong>${idx + 1}. ${f.name}</strong></div>
        <div style="font-size: 10px; color: #666;">
          ${f.category} | Priority: ${f.priorityScore}
        </div>
      </div>
    `;
  });
  
  html += `
      </div>
      <div style="margin-top: 12px; text-align: center;">
        <button onclick="downloadRiskReport('json')" style="padding: 6px 12px; margin-right: 6px; background: #1976d2; color: white; border: none; border-radius: 4px; cursor: pointer;">Download JSON</button>
        <button onclick="downloadRiskReport('txt')" style="padding: 6px 12px; background: #388e3c; color: white; border: none; border-radius: 4px; cursor: pointer;">Download TXT</button>
      </div>
    </div>
  `;
  
  alert('Risk Analysis Report generated. Check console for details.');
  console.log('[REPORT] Risk Analysis Report:', report);
}

/**
 * Download risk report as JSON or TXT file
 */
function downloadRiskReport(format) {
  const report = generateRiskAnalysisReport();
  let content, filename, mimeType;
  
  if (format === 'json') {
    content = JSON.stringify(report, null, 2);
    filename = `risk_report_${new Date().toISOString().split('T')[0]}.json`;
    mimeType = 'application/json';
  } else if (format === 'txt') {
    // Generate text format
    let textContent = `CRITICAL FACILITIES RISK ANALYSIS REPORT\n`;
    textContent += `${'='.repeat(60)}\n\n`;
    textContent += `Generated: ${report.timestamp}\n`;
    textContent += `Total Facilities: ${report.totalFacilities}\n\n`;
    
    textContent += `SUMMARY BY RISK LEVEL\n`;
    textContent += `${'-'.repeat(60)}\n`;
    Object.entries(report.summaryByRisk).forEach(([risk, data]) => {
      textContent += `${risk.toUpperCase()}: ${data.count} facilities\n`;
    });
    
    textContent += `\nSUMMARY BY CATEGORY\n`;
    textContent += `${'-'.repeat(60)}\n`;
    Object.entries(report.summaryByCategory).forEach(([category, data]) => {
      textContent += `${category}: ${data.count} facilities\n`;
      Object.entries(data.riskLevels).forEach(([risk, count]) => {
        textContent += `  - ${risk}: ${count}\n`;
      });
    });
    
    textContent += `\nTOP PRIORITY FACILITIES (Top 10)\n`;
    textContent += `${'-'.repeat(60)}\n`;
    report.topPriorityFacilities.forEach((f, idx) => {
      textContent += `${idx + 1}. ${f.name}\n`;
      textContent += `   Category: ${f.category}\n`;
      textContent += `   Risk Level: ${f.riskLevel}\n`;
      textContent += `   Priority Score: ${f.priorityScore}\n`;
      textContent += `   Vulnerabilities: ${f.vulnerabilities.join(', ')}\n\n`;
    });
    
    textContent += `VULNERABILITY MAP\n`;
    textContent += `${'-'.repeat(60)}\n`;
    Object.entries(report.vulnerabilityMap).forEach(([vuln, data]) => {
      textContent += `${vuln}: Found in ${data.count} facilities\n`;
      textContent += `   Facilities: ${data.facilities.join(', ')}\n\n`;
    });
    
    content = textContent;
    filename = `risk_report_${new Date().toISOString().split('T')[0]}.txt`;
    mimeType = 'text/plain';
  } else {
    return;
  }
  
  // Create and download file
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  console.log(`[EXPORT] Report exported as ${format.toUpperCase()}: ${filename}`);
}
