/**
 * AEGIS V3 — Backend Server
 * Express · SQLite per-project · OSM Nominatim + Overpass proxy
 * Inherits V2 facility detection; adds project/area management
 */

const express  = require('express');
const cors     = require('cors');
const axios    = require('axios');
const path     = require('path');
const fs       = require('fs');
const fsp      = require('fs').promises;
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const FacilityDatabaseManager = require('./facility-db-manager');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Data dirs ────────────────────────────────────────────────────
const DATA_DIR       = path.join(__dirname, 'data');
const PROJECTS_DIR   = path.join(DATA_DIR, 'projects');
const PROJECTS_INDEX = path.join(DATA_DIR, 'projects.json');

async function ensureDataDirs() {
  await fsp.mkdir(DATA_DIR,     { recursive: true });
  await fsp.mkdir(PROJECTS_DIR, { recursive: true });
  if (!fs.existsSync(PROJECTS_INDEX)) {
    await fsp.writeFile(PROJECTS_INDEX, '[]', 'utf8');
  }
}

// ── Middleware ───────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '50mb' }));   // area GeoJSON can be large
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

// ── Nominatim rate-limit guard (1 req / 1 s per OSM ToS) ────────
let lastNominatimCall = 0;
async function nominatimGet(url, params) {
  const now = Date.now();
  const wait = 1050 - (now - lastNominatimCall);
  if (wait > 0) await new Promise(r => setTimeout(r, wait));
  lastNominatimCall = Date.now();
  return axios.get(url, {
    params,
    headers: { 'User-Agent': 'AEGIS-V3/1.0 (cascading-risk-analysis-tool; contact@aegis.local)' },
    timeout: 12000
  });
}

// ════════════════════════════════════════════════════════════════
// PROJECT MANAGEMENT ROUTES
// ════════════════════════════════════════════════════════════════

/** Read the project index (summary list) */
async function readIndex() {
  try {
    return JSON.parse(await fsp.readFile(PROJECTS_INDEX, 'utf8'));
  } catch { return []; }
}
/** Write the project index */
async function writeIndex(data) {
  await fsp.writeFile(PROJECTS_INDEX, JSON.stringify(data, null, 2), 'utf8');
}
/** Read a single project's full metadata */
async function readProject(id) {
  const file = path.join(PROJECTS_DIR, id, 'project.json');
  if (!fs.existsSync(file)) return null;
  return JSON.parse(await fsp.readFile(file, 'utf8'));
}
/** Write a single project's full metadata */
async function writeProject(id, data) {
  await fsp.writeFile(path.join(PROJECTS_DIR, id, 'project.json'), JSON.stringify(data, null, 2), 'utf8');
}

/**
 * GET /api/projects
 * Optional query: ?mode=simulation|risk_analysis|realtime
 */
app.get('/api/projects', async (req, res) => {
  try {
    let index = await readIndex();
    if (req.query.mode) index = index.filter(p => p.mode === req.query.mode);
    index.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
    res.json(index);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/projects
 * Body: { name, mode, description?, area_name?, area: { source, geojson, meta } }
 */
app.post('/api/projects', async (req, res) => {
  try {
    const { name, mode, description, area_name, area } = req.body;
    if (!name || !mode) return res.status(400).json({ error: 'name and mode are required' });
    if (!['simulation','risk_analysis','realtime'].includes(mode))
      return res.status(400).json({ error: 'mode must be simulation | risk_analysis | realtime' });

    const id         = uuidv4();
    const now        = new Date().toISOString();
    const projectDir = path.join(PROJECTS_DIR, id);
    await fsp.mkdir(projectDir, { recursive: true });

    const project = {
      id, name, mode,
      description:  description  || '',
      area_name:    area_name    || 'Undefined area',
      area:         area         || null,
      grid:         { type: 'auto', config: {} },
      db_path:      path.join(projectDir, 'facilities.db'),
      created_at:   now,
      updated_at:   now
    };

    await writeProject(id, project);

    // Initialize project-specific SQLite DB
    const db = new FacilityDatabaseManager(project.db_path);
    await db.initialize();

    // Update index with summary
    const index = await readIndex();
    index.push({ id, name, mode, area_name: project.area_name, created_at: now, updated_at: now });
    await writeIndex(index);

    logStatus('success', `Project created: [${mode.toUpperCase()}] ${name} (${id})`);
    res.status(201).json(project);
  } catch (err) {
    logStatus('error', `Project create failed: ${err.message}`);
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/projects/:id
 * Returns full project metadata including area GeoJSON
 */
app.get('/api/projects/:id', async (req, res) => {
  try {
    const project = await readProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * PUT /api/projects/:id
 * Partial update. Protected fields: id, mode, db_path, created_at
 */
app.put('/api/projects/:id', async (req, res) => {
  try {
    const project = await readProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const PROTECTED = ['id','mode','db_path','created_at'];
    const updates   = Object.fromEntries(
      Object.entries(req.body).filter(([k]) => !PROTECTED.includes(k))
    );
    const updated = { ...project, ...updates, updated_at: new Date().toISOString() };
    await writeProject(req.params.id, updated);

    // Sync index summary
    const index = await readIndex();
    const idx   = index.findIndex(p => p.id === req.params.id);
    if (idx >= 0) {
      index[idx] = { ...index[idx], ...updates, updated_at: updated.updated_at };
      await writeIndex(index);
    }

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * DELETE /api/projects/:id
 */
app.delete('/api/projects/:id', async (req, res) => {
  try {
    const projectDir = path.join(PROJECTS_DIR, req.params.id);
    if (!fs.existsSync(projectDir)) return res.status(404).json({ error: 'Project not found' });

    await fsp.rm(projectDir, { recursive: true, force: true });

    const index = await readIndex();
    await writeIndex(index.filter(p => p.id !== req.params.id));

    logStatus('info', `Project deleted: ${req.params.id}`);
    res.json({ success: true, id: req.params.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════════
// OSM / NOMINATIM PROXY ROUTES
// ════════════════════════════════════════════════════════════════

/**
 * GET /api/osm/search?q=...&limit=...
 * Proxy to Nominatim search; returns polygon_geojson for boundary preview
 */
app.get('/api/osm/search', async (req, res) => {
  const { q, limit = 7 } = req.query;
  if (!q || q.length < 2) return res.status(400).json({ error: 'Query too short' });

  try {
    const r = await nominatimGet('https://nominatim.openstreetmap.org/search', {
      q,
      format:         'json',
      limit,
      addressdetails: 1,
      polygon_geojson: 1,
      featuretype:    'settlement'   // cities, towns, villages
    });
    // Also try without featuretype for admin areas (regions, etc.)
    if (r.data.length === 0) {
      const r2 = await nominatimGet('https://nominatim.openstreetmap.org/search', {
        q, format: 'json', limit, addressdetails: 1, polygon_geojson: 1
      });
      return res.json(r2.data);
    }
    res.json(r.data);
  } catch (err) {
    res.status(502).json({ error: `Nominatim error: ${err.message}` });
  }
});

/**
 * GET /api/osm/boundary/:osmType/:osmId
 * Fetch a specific OSM boundary polygon via Nominatim lookup
 * osmType: node | way | relation (N, W, R)
 */
app.get('/api/osm/boundary/:osmType/:osmId', async (req, res) => {
  const { osmType, osmId } = req.params;
  const prefixes = { node:'N', way:'W', relation:'R', n:'N', w:'W', r:'R' };
  const prefix   = prefixes[osmType.toLowerCase()];
  if (!prefix) return res.status(400).json({ error: 'osmType must be node | way | relation' });

  try {
    const r = await nominatimGet('https://nominatim.openstreetmap.org/lookup', {
      osm_ids:        `${prefix}${osmId}`,
      format:         'json',
      polygon_geojson: 1,
      addressdetails:  1
    });
    res.json(r.data);
  } catch (err) {
    res.status(502).json({ error: `Nominatim lookup error: ${err.message}` });
  }
});

/**
 * POST /api/osm/districts
 * Fetch sub-admin boundaries (districts / arrondissements) via Overpass
 * Body: { osmRelationId } OR { bbox: [south, west, north, east] }
 * Returns GeoJSON FeatureCollection
 */
app.post('/api/osm/districts', async (req, res) => {
  const { osmRelationId, bbox } = req.body;
  if (!osmRelationId && !bbox)
    return res.status(400).json({ error: 'Provide osmRelationId or bbox' });

  try {
    let query;
    if (osmRelationId) {
      // Fetch children of the given relation at admin_level 8–10
      query = `[out:json][timeout:40];
rel(${osmRelationId})->.parent;
(
  rel(r.parent)["boundary"="administrative"]["admin_level"~"^(8|9|10)$"];
);
out geom;`;
    } else {
      const [s, w, n, e] = bbox;
      query = `[out:json][timeout:40];
(
  relation["boundary"="administrative"]["admin_level"~"^(8|9|10)$"](${s},${w},${n},${e});
);
out geom;`;
    }

    const r = await axios.post('https://overpass-api.de/api/interpreter', query, {
      headers: { 'Content-Type': 'text/plain' },
      timeout: 40000
    });

    const features = osmElementsToGeoJSON(r.data.elements || []);
    res.json({ type: 'FeatureCollection', features });
  } catch (err) {
    res.status(502).json({ error: `Overpass error: ${err.message}` });
  }
});

/**
 * Convert Overpass `out geom` elements to GeoJSON Features
 * Handles relations with outer/inner ways
 */
function osmElementsToGeoJSON(elements) {
  const features = [];

  for (const el of elements) {
    if (el.type !== 'relation') continue;
    const props = {
      osm_id:      el.id,
      name:        el.tags?.name || el.tags?.['name:en'] || `Area ${el.id}`,
      admin_level: el.tags?.admin_level || null,
      boundary:    el.tags?.boundary    || null,
      ...el.tags
    };

    try {
      // Build rings from members
      const outerWays = (el.members || []).filter(m => m.type === 'way' && m.role === 'outer');
      const innerWays = (el.members || []).filter(m => m.type === 'way' && m.role === 'inner');

      if (!outerWays.length) continue;

      // Chain outer ways into a ring
      const outerRings = chainWaysToRings(outerWays);
      const innerRings = chainWaysToRings(innerWays);

      if (!outerRings.length) continue;

      const geometry = outerRings.length === 1 && innerRings.length === 0
        ? { type: 'Polygon',   coordinates: [outerRings[0], ...innerRings] }
        : { type: 'MultiPolygon', coordinates: outerRings.map(r => [r]) };

      features.push({ type: 'Feature', properties: props, geometry });
    } catch { /* skip malformed element */ }
  }

  return features;
}

function chainWaysToRings(ways) {
  if (!ways.length) return [];
  const rings = [];

  // Clone ways array
  let remaining = ways.map(w => ({
    nodes: (w.geometry || []).map(n => [n.lon, n.lat])
  })).filter(w => w.nodes.length >= 2);

  while (remaining.length) {
    let ring = [...remaining[0].nodes];
    remaining = remaining.slice(1);
    let changed = true;
    while (changed) {
      changed = false;
      for (let i = 0; i < remaining.length; i++) {
        const w = remaining[i];
        const ringEnd   = ring[ring.length - 1];
        const wStart    = w.nodes[0];
        const wEnd      = w.nodes[w.nodes.length - 1];

        if (coordsEqual(ringEnd, wStart)) {
          ring = [...ring, ...w.nodes.slice(1)];
          remaining.splice(i, 1); changed = true; break;
        } else if (coordsEqual(ringEnd, wEnd)) {
          ring = [...ring, ...[...w.nodes].reverse().slice(1)];
          remaining.splice(i, 1); changed = true; break;
        }
      }
    }
    // Close ring
    if (!coordsEqual(ring[0], ring[ring.length - 1])) ring.push(ring[0]);
    if (ring.length >= 4) rings.push(ring);
  }

  return rings;
}

function coordsEqual([ax, ay], [bx, by]) {
  return Math.abs(ax - bx) < 0.000001 && Math.abs(ay - by) < 0.000001;
}

// ════════════════════════════════════════════════════════════════
// V2 FACILITY DETECTION ROUTES (preserved from previous version)
// ════════════════════════════════════════════════════════════════

const FACILITY_CATEGORIES = {
  HOSPITAL:         { id:'hospital',       name:'Hospital',          riskLevel:'critical',  googleTypes:['hospital'],        osmTags:['amenity=hospital'] },
  CLINIC:           { id:'clinic',         name:'Clinic',            riskLevel:'high',      googleTypes:['doctor'],          osmTags:['amenity=clinic'] },
  FIRE_STATION:     { id:'fire_station',   name:'Fire Station',      riskLevel:'critical',  googleTypes:['fire_station'],    osmTags:['amenity=fire_station'] },
  POLICE:           { id:'police',         name:'Police Station',    riskLevel:'critical',  googleTypes:['police'],          osmTags:['amenity=police'] },
  SCHOOL:           { id:'school',         name:'School',            riskLevel:'high',      googleTypes:['school'],          osmTags:['amenity=school'] },
  GYMNASIUM:        { id:'gymnasium',      name:'Gymnasium',         riskLevel:'high',      googleTypes:['gym'],             osmTags:['leisure=sports_centre'] },
  SHELTER:          { id:'shelter',        name:'Shelter',           riskLevel:'high',      googleTypes:[],                  osmTags:['amenity=shelter','amenity=community_centre'] },
  POWER_PLANT:      { id:'power_plant',    name:'Power Plant',       riskLevel:'hazardous', googleTypes:[],                  osmTags:['power=plant'] },
  SUBSTATION:       { id:'substation',     name:'Power Substation',  riskLevel:'hazardous', googleTypes:[],                  osmTags:['power=substation'] },
  CHEMICAL_PLANT:   { id:'chemical_plant', name:'Chemical Plant',    riskLevel:'hazardous', googleTypes:[],                  osmTags:['industrial=chemical'] },
  PETROLEUM:        { id:'petroleum',      name:'Petroleum Facility', riskLevel:'hazardous',googleTypes:[],                  osmTags:['industrial=oil_refinery','man_made=petroleum_well'] },
  WASTE_MANAGEMENT: { id:'waste',          name:'Waste Facility',    riskLevel:'hazardous', googleTypes:[],                  osmTags:['amenity=waste_transfer_station','waste=landfill'] },
  WATER_TREATMENT:  { id:'water',          name:'Water Treatment',   riskLevel:'hazardous', googleTypes:[],                  osmTags:['man_made=water_treatment_plant'] },
  AIRPORT:          { id:'airport',        name:'Airport',           riskLevel:'high',      googleTypes:['airport'],         osmTags:['aeroway=aerodrome'] },
  TRAIN_STATION:    { id:'train_station',  name:'Train Station',     riskLevel:'medium',    googleTypes:['train_station'],   osmTags:['railway=station'] },
  WATER_SUPPLY:     { id:'water_supply',   name:'Water Supply',      riskLevel:'medium',    googleTypes:[],                  osmTags:['man_made=reservoir','man_made=water_tower'] },
  COMMUNICATION:    { id:'communication',  name:'Telecom Tower',     riskLevel:'medium',    googleTypes:[],                  osmTags:['man_made=mast','man_made=tower'] },
};

async function queryOverpassAPI(bounds) {
  const { north, south, east, west } = bounds;
  const query = `[out:json][timeout:30];
(
  node["amenity"="hospital"](${south},${west},${north},${east});
  way["amenity"="hospital"](${south},${west},${north},${east});
  node["amenity"="fire_station"](${south},${west},${north},${east});
  way["amenity"="fire_station"](${south},${west},${north},${east});
  node["amenity"="police"](${south},${west},${north},${east});
  way["amenity"="police"](${south},${west},${north},${east});
  node["amenity"="school"](${south},${west},${north},${east});
  way["amenity"="school"](${south},${west},${north},${east});
  node["power"="plant"](${south},${west},${north},${east});
  way["power"="plant"](${south},${west},${north},${east});
  node["power"="substation"](${south},${west},${north},${east});
  way["power"="substation"](${south},${west},${north},${east});
  node["industrial"="chemical"](${south},${west},${north},${east});
  way["industrial"="chemical"](${south},${west},${north},${east});
  node["industrial"="oil_refinery"](${south},${west},${north},${east});
  way["industrial"="oil_refinery"](${south},${west},${north},${east});
  node["man_made"="water_treatment_plant"](${south},${west},${north},${east});
  way["man_made"="water_treatment_plant"](${south},${west},${north},${east});
);
out center;`;

  try {
    const r = await axios.post('https://overpass-api.de/api/interpreter', query, {
      timeout: 30000,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });
    return r.data.elements || [];
  } catch (err) {
    logStatus('error', `Overpass query failed: ${err.message}`);
    return [];
  }
}

function classifyOsmElement(el) {
  const tags = el.tags || {};
  for (const [, cat] of Object.entries(FACILITY_CATEGORIES)) {
    for (const osmTag of cat.osmTags) {
      const [k, v] = osmTag.split('=');
      if (tags[k] === v) return cat;
    }
  }
  return null;
}

function getRiskColor(level) {
  return { critical:'#d32f2f', hazardous:'#f57c00', high:'#fbc02d', medium:'#1976d2', low:'#388e3c' }[level] || '#757575';
}

/**
 * POST /api/detect-facilities
 * V2-compatible facility detection; now accepts optional projectId
 */
app.post('/api/detect-facilities', async (req, res) => {
  try {
    const { bounds, projectId } = req.body;
    if (!bounds) return res.status(400).json({ error: 'bounds required' });

    const osmElements = await queryOverpassAPI(bounds);
    const facilities  = [];

    for (const el of osmElements) {
      const cat = classifyOsmElement(el);
      if (!cat) continue;

      const lat = el.lat  || el.center?.lat;
      const lng = el.lon  || el.center?.lon;
      if (!lat || !lng) continue;

      const id = uuidv4();
      facilities.push({
        id,
        source:    'overpass',
        osm_id:    el.id,
        name:      el.tags?.name || cat.name,
        category:  cat.id,
        category_name: cat.name,
        risk_level: cat.riskLevel,
        color:     getRiskColor(cat.riskLevel),
        latitude:  lat,
        longitude: lng,
        tags:      el.tags || {},
        detected_at: new Date().toISOString()
      });
    }

    // If projectId provided, persist to project DB
    if (projectId) {
      const project = await readProject(projectId);
      if (project?.db_path) {
        try {
          const db = new FacilityDatabaseManager(project.db_path);
          await db.initialize();
          for (const f of facilities) await db.addFacility(f);
          logStatus('info', `Persisted ${facilities.length} facilities to project ${projectId}`);
        } catch (dbErr) {
          logStatus('error', `DB persist error: ${dbErr.message}`);
        }
      }
    }

    res.json({ facilities, count: facilities.length, timestamp: new Date().toISOString() });
  } catch (err) {
    logStatus('error', `detect-facilities: ${err.message}`);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════════
// HEALTH CHECK
// ════════════════════════════════════════════════════════════════

app.get('/api/health', async (req, res) => {
  const index = await readIndex().catch(() => []);
  res.json({
    status:            'ok',
    version:           '3.0.0-alpha',
    timestamp:         new Date().toISOString(),
    project_count:     index.length,
    google_places_key: !!process.env.GOOGLE_PLACES_API_KEY,
    overpass:          true,
    nominatim:         true
  });
});

// ── Error handler ─────────────────────────────────────────────────
app.use((err, req, res, next) => {
  logStatus('error', `Unhandled: ${err.message}`);
  res.status(500).json({ error: 'Internal server error', message: err.message });
});

// ── Logging helpers ───────────────────────────────────────────────
const C = {
  reset:'\x1b[0m', bright:'\x1b[1m', dim:'\x1b[2m',
  red:'\x1b[31m', green:'\x1b[32m', yellow:'\x1b[33m',
  blue:'\x1b[34m', magenta:'\x1b[35m', cyan:'\x1b[36m', white:'\x1b[37m'
};

function logStatus(type, msg) {
  const ts = new Date().toISOString().slice(11, 19);
  const prefix = `${C.dim}[${ts}]${C.reset}`;
  switch(type) {
    case 'success': console.log(`${prefix} ${C.green}✓${C.reset} ${C.green}${msg}${C.reset}`); break;
    case 'info':    console.log(`${prefix} ${C.cyan}ℹ${C.reset} ${C.cyan}${msg}${C.reset}`);  break;
    case 'warning': console.log(`${prefix} ${C.yellow}⚠${C.reset} ${C.yellow}${msg}${C.reset}`); break;
    case 'error':   console.log(`${prefix} ${C.red}✗${C.reset} ${C.red}${msg}${C.reset}`);   break;
    case 'server':  console.log(`${prefix} ${C.magenta}◆${C.reset} ${C.magenta}${msg}${C.reset}`); break;
    default:        console.log(`${prefix} ${msg}`);
  }
}

function printBanner() {
  console.log('');
  console.log(`${C.cyan}${C.bright}╔═══════════════════════════════════════════════════════════╗${C.reset}`);
  console.log(`${C.cyan}${C.bright}║${C.reset}  ${C.white}${C.bright}AEGIS V3 — Adaptive Emergency Geospatial Intelligence${C.reset}  ${C.cyan}${C.bright}║${C.reset}`);
  console.log(`${C.cyan}${C.bright}║${C.reset}  ${C.dim}Cascading Risk Analysis · Predictive Modelling · DRR${C.reset}    ${C.cyan}${C.bright}║${C.reset}`);
  console.log(`${C.cyan}${C.bright}╚═══════════════════════════════════════════════════════════╝${C.reset}`);
  console.log('');
}

// ── Start ─────────────────────────────────────────────────────────
app.listen(PORT, async () => {
  printBanner();
  await ensureDataDirs();
  logStatus('server',  `Listening on port ${C.bright}${PORT}${C.reset}`);
  logStatus('success', 'Project management: ready');
  logStatus('success', 'OSM Nominatim proxy: ready (rate-limited to 1 req/s)');
  logStatus('success', 'Overpass API: ready');
  if (process.env.GOOGLE_PLACES_API_KEY) {
    logStatus('success', 'Google Places API: configured');
  } else {
    logStatus('warning', 'Google Places API: no key set — Overpass only');
  }
  logStatus('info', `Data directory: ${DATA_DIR}`);
  console.log('');
  logStatus('success', `${C.bright}Server ready.${C.reset} http://localhost:${PORT}`);
  console.log('');
});

module.exports = app;
